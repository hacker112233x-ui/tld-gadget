import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, Order, CheckoutForm, ProductCategory } from '../types';
import { PRODUCTS } from '../data/products';

export const STORE_PHONE_NUMBER = '+8801742428157';
export const STORE_PHONE_DISPLAY = '+880 1742-428157';

interface ShopContextType {
  // Theme
  isDark: boolean;
  toggleTheme: () => void;

  // Search & Filter
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: ProductCategory;
  setSelectedCategory: (cat: ProductCategory) => void;
  sortBy: 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'discount';
  setSortBy: (sort: 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'discount') => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, openDrawer?: boolean) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, delta: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  cartCount: number;
  subtotal: number;
  deliveryFee: number;
  deliveryZone: 'dhaka' | 'outside_dhaka';
  setDeliveryZone: (zone: 'dhaka' | 'outside_dhaka') => void;
  freeDeliveryThreshold: number;
  freeDeliveryProgress: number;
  promoCode: string;
  promoDiscount: number;
  promoError: string | null;
  applyPromoCode: (code: string) => boolean;
  removePromoCode: () => void;
  totalAmount: number;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  isWishlistOpen: boolean;
  setIsWishlistOpen: (open: boolean) => void;

  // Product Modal
  selectedProduct: Product | null;
  setSelectedProduct: (product: Product | null) => void;

  // Checkout
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  buyNowProduct: { product: Product; quantity: number } | null;
  initiateBuyNow: (product: Product, quantity?: number) => void;
  submitOrder: (details: CheckoutForm) => Order;

  // Order Confirmation
  lastOrder: Order | null;
  setLastOrder: (order: Order | null) => void;

  // Policy Modal
  activePolicy: string | null;
  setActivePolicy: (policy: string | null) => void;

  // WhatsApp quick chat
  isWhatsAppOpen: boolean;
  setIsWhatsAppOpen: (open: boolean) => void;

  // Mobile Sliding Navigation Menu Drawer
  isMenuDrawerOpen: boolean;
  setIsMenuDrawerOpen: (open: boolean) => void;

  // Auth Modal (Login / Register)
  authModalMode: 'login' | 'register' | null;
  setAuthModalMode: (mode: 'login' | 'register' | null) => void;

  // Active View Tab ('store' | 'digital' | 'leaderboard')
  activeTab: 'store' | 'digital' | 'leaderboard';
  setActiveTab: (tab: 'store' | 'digital' | 'leaderboard') => void;

  // Toast feedback
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Theme state
  const [isDark, setIsDark] = useState<boolean>(() => {
    const saved = localStorage.getItem('tld_theme');
    return saved ? saved === 'dark' : true;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      localStorage.setItem('tld_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('tld_theme', 'light');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(prev => !prev);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('All');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating' | 'discount'>('featured');

  // Navigation Drawers & Modals
  const [isMenuDrawerOpen, setIsMenuDrawerOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | null>(null);
  const [activeTab, setActiveTab] = useState<'store' | 'digital' | 'leaderboard'>('store');

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('tld_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [deliveryZone, setDeliveryZone] = useState<'dhaka' | 'outside_dhaka'>('dhaka');
  const [promoCode, setPromoCode] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<string | null>(null);
  const [promoDiscount, setPromoDiscount] = useState(0);
  const [promoError, setPromoError] = useState<string | null>(null);

  // Save Cart to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('tld_cart', JSON.stringify(cart));
    } catch {
      // ignore
    }
  }, [cart]);

  // Wishlist
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('tld_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isWishlistOpen, setIsWishlistOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('tld_wishlist', JSON.stringify(wishlist));
    } catch {
      // ignore
    }
  }, [wishlist]);

  const toggleWishlist = (productId: string) => {
    setWishlist(prev => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast('Removed from wishlist');
        return prev.filter(id => id !== productId);
      } else {
        showToast('Added to wishlist ❤️');
        return [...prev, productId];
      }
    });
  };

  const isWishlisted = (productId: string) => wishlist.includes(productId);

  // Modals
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [buyNowProduct, setBuyNowProduct] = useState<{ product: Product; quantity: number } | null>(null);
  const [lastOrder, setLastOrder] = useState<Order | null>(null);
  const [activePolicy, setActivePolicy] = useState<string | null>(null);
  const [isWhatsAppOpen, setIsWhatsAppOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(current => (current === msg ? null : current));
    }, 2800);
  };

  const addToCart = (product: Product, quantity = 1, openDrawer = false) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: Math.min(item.quantity + quantity, product.stockCount) }
            : item
        );
      }
      return [...prev, { product, quantity: Math.min(quantity, product.stockCount) }];
    });
    showToast(`Added "${product.name.slice(0, 22)}..." to cart`);
    if (openDrawer) {
      setIsCartOpen(true);
    }
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
    showToast('Item removed from cart');
  };

  const updateCartQuantity = (productId: string, delta: number) => {
    setCart(prev =>
      prev
        .map(item => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            if (newQty <= 0) return null;
            return {
              ...item,
              quantity: Math.min(newQty, item.product.stockCount),
            };
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const clearCart = () => {
    setCart([]);
    setAppliedPromo(null);
    setPromoDiscount(0);
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const freeDeliveryThreshold = 2000;
  const isFreeDeliveryEligible = subtotal >= freeDeliveryThreshold || appliedPromo === 'FREEBD';
  const baseDeliveryRate = deliveryZone === 'dhaka' ? 60 : 120;
  const deliveryFee = cart.length === 0 ? 0 : (isFreeDeliveryEligible ? 0 : baseDeliveryRate);
  const freeDeliveryProgress = Math.min(100, Math.round((subtotal / freeDeliveryThreshold) * 100));

  const applyPromoCode = (code: string) => {
    const clean = code.trim().toUpperCase();
    if (!clean) {
      setPromoError('Please enter a coupon code');
      return false;
    }
    if (subtotal === 0) {
      setPromoError('Add items to cart before applying coupon');
      return false;
    }

    if (clean === 'TLD10') {
      const discount = Math.round(subtotal * 0.1);
      setPromoDiscount(discount);
      setAppliedPromo('TLD10');
      setPromoError(null);
      showToast('🎉 Coupon TLD10 applied: 10% OFF!');
      return true;
    } else if (clean === 'GAMERBD') {
      const discount = 100;
      setPromoDiscount(discount);
      setAppliedPromo('GAMERBD');
      setPromoError(null);
      showToast('🎉 Coupon GAMERBD applied: ৳100 OFF!');
      return true;
    } else if (clean === 'FREEBD') {
      setAppliedPromo('FREEBD');
      setPromoDiscount(0);
      setPromoError(null);
      showToast('🎉 Coupon FREEBD applied: FREE Delivery!');
      return true;
    } else {
      setPromoError('Invalid coupon code. Try "TLD10" or "GAMERBD"');
      return false;
    }
  };

  const removePromoCode = () => {
    setAppliedPromo(null);
    setPromoDiscount(0);
    setPromoCode('');
    setPromoError(null);
    showToast('Coupon removed');
  };

  const totalAmount = Math.max(0, subtotal - promoDiscount + deliveryFee);

  const initiateBuyNow = (product: Product, quantity = 1) => {
    setBuyNowProduct({ product, quantity });
    setIsCheckoutOpen(true);
  };

  const submitOrder = (details: CheckoutForm): Order => {
    const isSingleBuyNow = Boolean(buyNowProduct);
    const orderItems: CartItem[] = isSingleBuyNow && buyNowProduct
      ? [buyNowProduct]
      : [...cart];

    const orderSubtotal = orderItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const orderDeliveryFee = (orderSubtotal >= freeDeliveryThreshold || appliedPromo === 'FREEBD')
      ? 0
      : (details.city === 'dhaka' ? 60 : 120);

    const orderDiscount = isSingleBuyNow ? 0 : promoDiscount;
    const finalBill = Math.max(0, orderSubtotal - orderDiscount + orderDeliveryFee);

    const orderNum = Math.floor(10000 + Math.random() * 90000);
    const newOrder: Order = {
      orderId: `TLD-${orderNum}`,
      createdAt: new Date().toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      items: orderItems,
      subtotal: orderSubtotal,
      deliveryFee: orderDeliveryFee,
      discountAmount: orderDiscount,
      couponCode: appliedPromo || undefined,
      totalAmount: finalBill,
      shippingDetails: details,
      status: 'Confirmed'
    };

    if (!isSingleBuyNow) {
      clearCart();
    }
    setBuyNowProduct(null);
    setIsCheckoutOpen(false);
    setLastOrder(newOrder);
    return newOrder;
  };

  return (
    <ShopContext.Provider
      value={{
        isDark,
        toggleTheme,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        sortBy,
        setSortBy,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        cartCount,
        subtotal,
        deliveryFee,
        deliveryZone,
        setDeliveryZone,
        freeDeliveryThreshold,
        freeDeliveryProgress,
        promoCode,
        promoDiscount,
        promoError,
        applyPromoCode,
        removePromoCode,
        totalAmount,
        wishlist,
        toggleWishlist,
        isWishlisted,
        isWishlistOpen,
        setIsWishlistOpen,
        selectedProduct,
        setSelectedProduct,
        isCheckoutOpen,
        setIsCheckoutOpen,
        buyNowProduct,
        initiateBuyNow,
        submitOrder,
        lastOrder,
        setLastOrder,
        activePolicy,
        setActivePolicy,
        isWhatsAppOpen,
        setIsWhatsAppOpen,
        isMenuDrawerOpen,
        setIsMenuDrawerOpen,
        authModalMode,
        setAuthModalMode,
        activeTab,
        setActiveTab,
        toastMessage,
        showToast
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
