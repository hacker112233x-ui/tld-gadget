import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { CheckoutForm } from '../types';
import { 
  X, 
  ShieldCheck, 
  Truck, 
  CreditCard, 
  Banknote, 
  Smartphone, 
  CheckCircle2, 
  AlertCircle,
  Copy,
  Check
} from 'lucide-react';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    buyNowProduct,
    subtotal,
    deliveryZone,
    setDeliveryZone,
    freeDeliveryThreshold,
    promoDiscount,
    submitOrder,
    showToast
  } = useShop();

  const isBuyNow = Boolean(buyNowProduct);
  const items = isBuyNow && buyNowProduct ? [buyNowProduct] : cart;

  const currentSubtotal = isBuyNow && buyNowProduct 
    ? buyNowProduct.product.price * buyNowProduct.quantity 
    : subtotal;

  const [formData, setFormData] = useState<CheckoutForm>({
    customerName: '',
    phone: '',
    address: '',
    city: deliveryZone,
    areaNote: '',
    paymentMethod: 'cod',
    trxId: ''
  });

  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isCheckoutOpen) return null;

  const isFreeDelivery = currentSubtotal >= freeDeliveryThreshold;
  const currentDeliveryFee = isFreeDelivery ? 0 : (formData.city === 'dhaka' ? 60 : 120);
  const finalDiscount = isBuyNow ? 0 : promoDiscount;
  const orderTotal = Math.max(0, currentSubtotal - finalDiscount + currentDeliveryFee);

  const handleCopyNumber = (num: string) => {
    navigator.clipboard.writeText(num);
    setCopiedNumber(true);
    showToast('Payment number copied to clipboard');
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const validate = () => {
    const errors: { [key: string]: string } = {};
    if (!formData.customerName.trim()) {
      errors.customerName = 'Please enter your full name';
    }

    const cleanPhone = formData.phone.trim().replace(/[-+\s]/g, '');
    const bdPhoneRegex = /^(?:\+?880|0)?1[3-9]\d{8}$/;
    if (!cleanPhone) {
      errors.phone = 'Mobile number is required';
    } else if (!bdPhoneRegex.test(cleanPhone)) {
      errors.phone = 'Please enter a valid 11-digit Bangladeshi mobile number (e.g., 01712345678)';
    }

    if (!formData.address.trim() || formData.address.trim().length < 5) {
      errors.address = 'Please provide a detailed delivery address (House, Road, Area, Thana)';
    }

    if ((formData.paymentMethod === 'bkash' || formData.paymentMethod === 'nagad') && !formData.trxId?.trim()) {
      errors.trxId = `Please enter the ${formData.paymentMethod.toUpperCase()} Transaction ID (TrxID)`;
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      submitOrder(formData);
      setIsSubmitting(false);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div 
        className="relative w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div>
            <span className="text-[11px] font-mono text-emerald-400 uppercase font-semibold">
              TLD GADGET.BD Fast Checkout
            </span>
            <h2 className="text-lg sm:text-xl font-bold text-white font-display uppercase tracking-wider">
              {isBuyNow ? 'Quick Direct Checkout' : 'Complete Your Order'}
            </h2>
          </div>

          <button
            type="button"
            onClick={() => setIsCheckoutOpen(false)}
            className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Order Brief Summary */}
          <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
            <h4 className="text-xs font-mono uppercase text-neutral-400 font-semibold mb-2">
              Items to Deliver ({items.reduce((s, i) => s + i.quantity, 0)} items)
            </h4>
            <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
              {items.map((item) => (
                <div key={item.product.id} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 truncate pr-2">
                    <span className="font-mono text-neutral-500 font-bold">x{item.quantity}</span>
                    <span className="text-neutral-200 truncate">{item.product.name}</span>
                  </div>
                  <span className="font-mono-numbers text-white font-semibold shrink-0">
                    ৳{(item.product.price * item.quantity).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Customer Details */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 text-xs flex items-center justify-center font-bold">1</span>
              Delivery Contact Information
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.customerName}
                  onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                  placeholder="e.g. Tanvir Ahmed"
                  className={`w-full bg-neutral-950 border text-sm text-white rounded-lg p-2.5 focus:outline-none focus:ring-1 ${
                    formErrors.customerName ? 'border-rose-500 focus:ring-rose-500' : 'border-neutral-800 focus:border-emerald-500 focus:ring-emerald-500'
                  }`}
                />
                {formErrors.customerName && (
                  <p className="text-[11px] text-rose-400 mt-1">{formErrors.customerName}</p>
                )}
              </div>

              {/* Phone Number */}
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  Mobile Number (BD) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="017XXXXXXXX"
                  className={`w-full bg-neutral-950 border text-sm text-white rounded-lg p-2.5 font-mono focus:outline-none focus:ring-1 ${
                    formErrors.phone ? 'border-rose-500 focus:ring-rose-500' : 'border-neutral-800 focus:border-emerald-500 focus:ring-emerald-500'
                  }`}
                />
                {formErrors.phone && (
                  <p className="text-[11px] text-rose-400 mt-1">{formErrors.phone}</p>
                )}
              </div>
            </div>

            {/* City Selection */}
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Delivery Location <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                  formData.city === 'dhaka'
                    ? 'border-emerald-500 bg-emerald-500/10 text-white'
                    : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
                }`}>
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="city"
                      checked={formData.city === 'dhaka'}
                      onChange={() => {
                        setFormData({ ...formData, city: 'dhaka' });
                        setDeliveryZone('dhaka');
                      }}
                      className="text-emerald-500 focus:ring-emerald-500"
                    />
                    <span className="text-xs font-semibold">Inside Dhaka</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-400">
                    {isFreeDelivery ? 'FREE' : '৳60'}
                  </span>
                </label>

                <label className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                  formData.city === 'outside_dhaka'
                    ? 'border-emerald-500 bg-emerald-500/10 text-white'
                    : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
                }`}>
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="city"
                      checked={formData.city === 'outside_dhaka'}
                      onChange={() => {
                        setFormData({ ...formData, city: 'outside_dhaka' });
                        setDeliveryZone('outside_dhaka');
                      }}
                      className="text-emerald-500 focus:ring-emerald-500"
                    />
                    <span className="text-xs font-semibold">Outside Dhaka</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-400">
                    {isFreeDelivery ? 'FREE' : '৳120'}
                  </span>
                </label>
              </div>
            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Complete Delivery Address <span className="text-rose-500">*</span>
              </label>
              <textarea
                rows={2}
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="House No, Road No, Sector / Village, Thana, District"
                className={`w-full bg-neutral-950 border text-sm text-white rounded-lg p-2.5 focus:outline-none focus:ring-1 ${
                  formErrors.address ? 'border-rose-500 focus:ring-rose-500' : 'border-neutral-800 focus:border-emerald-500 focus:ring-emerald-500'
                }`}
              />
              {formErrors.address && (
                <p className="text-[11px] text-rose-400 mt-1">{formErrors.address}</p>
              )}
            </div>

            {/* Order Note */}
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">
                Special Delivery Instructions (Optional)
              </label>
              <input
                type="text"
                value={formData.areaNote}
                onChange={(e) => setFormData({ ...formData, areaNote: e.target.value })}
                placeholder="e.g. Call before delivery, deliver after 3 PM"
                className="w-full bg-neutral-950 border border-neutral-800 text-sm text-white rounded-lg p-2.5 focus:outline-none focus:border-neutral-700"
              />
            </div>
          </div>

          {/* Payment Method */}
          <div className="space-y-3 pt-4 border-t border-neutral-800">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 text-xs flex items-center justify-center font-bold">2</span>
              Select Payment Method
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Cash on Delivery */}
              <label className={`p-3 rounded-xl border cursor-pointer flex flex-col justify-between transition-all ${
                formData.paymentMethod === 'cod'
                  ? 'border-emerald-500 bg-emerald-500/10 text-white'
                  : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
              }`}>
                <div className="flex items-center justify-between mb-1.5">
                  <Banknote className="w-5 h-5 text-emerald-400" />
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={formData.paymentMethod === 'cod'}
                    onChange={() => setFormData({ ...formData, paymentMethod: 'cod' })}
                    className="text-emerald-500"
                  />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">Cash on Delivery</span>
                  <span className="text-[10px] text-neutral-400">Pay when parcel arrives</span>
                </div>
              </label>

              {/* bKash */}
              <label className={`p-3 rounded-xl border cursor-pointer flex flex-col justify-between transition-all ${
                formData.paymentMethod === 'bkash'
                  ? 'border-pink-500 bg-pink-500/10 text-white'
                  : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
              }`}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-black font-mono text-pink-500 bg-pink-500/20 px-1.5 py-0.5 rounded">
                    bKash
                  </span>
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={formData.paymentMethod === 'bkash'}
                    onChange={() => setFormData({ ...formData, paymentMethod: 'bkash' })}
                    className="text-pink-500"
                  />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">bKash Payment</span>
                  <span className="text-[10px] text-neutral-400">Instant Send Money</span>
                </div>
              </label>

              {/* Nagad */}
              <label className={`p-3 rounded-xl border cursor-pointer flex flex-col justify-between transition-all ${
                formData.paymentMethod === 'nagad'
                  ? 'border-orange-500 bg-orange-500/10 text-white'
                  : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
              }`}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-black font-mono text-orange-500 bg-orange-500/20 px-1.5 py-0.5 rounded">
                    Nagad
                  </span>
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={formData.paymentMethod === 'nagad'}
                    onChange={() => setFormData({ ...formData, paymentMethod: 'nagad' })}
                    className="text-orange-500"
                  />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">Nagad Payment</span>
                  <span className="text-[10px] text-neutral-400">Personal / Merchant</span>
                </div>
              </label>
            </div>

            {/* If bKash or Nagad chosen, show payment instructions */}
            {(formData.paymentMethod === 'bkash' || formData.paymentMethod === 'nagad') && (
              <div className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs text-neutral-300">
                    <span className="text-neutral-400">Send Money / Payment to: </span>
                    <strong className="font-mono text-emerald-400 text-sm">01742-428157</strong>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopyNumber('01742428157')}
                    className="flex items-center gap-1 text-[11px] px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white rounded border border-neutral-700 transition-colors"
                  >
                    {copiedNumber ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedNumber ? 'Copied' : 'Copy Number'}</span>
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-medium text-neutral-300 mb-1">
                    Enter Transaction ID (TrxID) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.trxId}
                    onChange={(e) => setFormData({ ...formData, trxId: e.target.value })}
                    placeholder="e.g. 9J4K2L8X10"
                    className="w-full bg-neutral-900 border border-neutral-700 text-sm text-white font-mono uppercase rounded-lg p-2 focus:outline-none focus:border-emerald-500"
                  />
                  {formErrors.trxId && (
                    <p className="text-[11px] text-rose-400 mt-1">{formErrors.trxId}</p>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Final Bill Breakdown */}
          <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2 text-xs">
            <div className="flex justify-between text-neutral-400">
              <span>Items Total</span>
              <span className="font-mono-numbers text-neutral-200">৳{currentSubtotal.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Delivery Fee ({formData.city === 'dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'})</span>
              <span className="font-mono-numbers text-neutral-200">
                {currentDeliveryFee === 0 ? <span className="text-emerald-400 font-bold">FREE</span> : `৳${currentDeliveryFee}`}
              </span>
            </div>
            {finalDiscount > 0 && (
              <div className="flex justify-between text-emerald-400">
                <span>Coupon Savings</span>
                <span className="font-mono-numbers">-৳{finalDiscount.toLocaleString()}</span>
              </div>
            )}
            <div className="flex justify-between text-base font-bold text-white pt-2 border-t border-neutral-800">
              <span className="font-display uppercase tracking-wider">Total Payable</span>
              <span className="text-emerald-400 font-mono-numbers text-xl">
                ৳{orderTotal.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center gap-2 py-3.5 px-6 bg-emerald-500 hover:bg-emerald-400 active:scale-98 text-neutral-950 font-bold text-base rounded-xl shadow-[0_0_20px_rgba(16,185,129,0.35)] transition-all font-display uppercase tracking-wider disabled:opacity-50 cursor-pointer"
          >
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                Processing Order...
              </span>
            ) : (
              <span>Confirm Order (৳{orderTotal.toLocaleString()})</span>
            )}
          </button>

          {/* Trust notice */}
          <div className="flex items-center justify-center gap-2 text-[11px] text-neutral-500 text-center">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>100% Secure Checkout · Instant confirmation via SMS & WhatsApp</span>
          </div>
        </form>
      </div>
    </div>
  );
};
