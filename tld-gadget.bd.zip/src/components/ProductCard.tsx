import React from 'react';
import { Product } from '../types';
import { useShop } from '../context/ShopContext';
import { getProductImageUrl, coolerImg } from '../data/products';
import { Heart, ShoppingCart, Zap, Star, ShieldCheck } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { 
    addToCart, 
    initiateBuyNow, 
    toggleWishlist, 
    isWishlisted, 
    setSelectedProduct 
  } = useShop();

  const wishlisted = isWishlisted(product.id);
  const isStockLow = product.stockCount <= 5;

  return (
    <div className="group relative flex flex-col justify-between rounded-xl bg-neutral-900 border border-neutral-800/90 hover:border-emerald-500/50 hover:shadow-[0_4px_24px_rgba(16,185,129,0.12)] transition-all duration-200 overflow-hidden">
      {/* Top Image Preview Container */}
      <div 
        onClick={() => setSelectedProduct(product)}
        className="relative w-full aspect-[4/3] bg-neutral-950 overflow-hidden cursor-pointer"
      >
        <img
          src={getProductImageUrl(product.image)}
          alt={product.name}
          onError={(e) => {
            (e.target as HTMLImageElement).src = coolerImg;
          }}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-500 ease-out"
        />

        {/* Subtle Dark Edge Vignette */}
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/60 via-transparent to-transparent pointer-events-none" />

        {/* Discount Badge */}
        {product.discountPercent > 0 && (
          <div className="absolute top-2.5 left-2.5 z-10">
            <span className="inline-flex items-center px-2 py-0.5 text-[11px] font-mono font-bold bg-rose-600 text-white rounded">
              -{product.discountPercent}% OFF
            </span>
          </div>
        )}

        {/* Stock Alert Badge */}
        {isStockLow ? (
          <div className="absolute bottom-2.5 left-2.5 z-10">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-mono font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded backdrop-blur-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
              Only {product.stockCount} left
            </span>
          </div>
        ) : (
          <div className="absolute bottom-2.5 left-2.5 z-10">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-mono font-medium text-emerald-400 bg-neutral-950/70 border border-emerald-500/30 rounded backdrop-blur-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              In Stock
            </span>
          </div>
        )}

        {/* Wishlist Heart Toggle Button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
          className={`absolute top-2.5 right-2.5 z-10 p-2 rounded-lg backdrop-blur-md transition-all duration-150 ${
            wishlisted 
              ? 'bg-rose-500/20 text-rose-500 border border-rose-500/40' 
              : 'bg-neutral-950/60 text-neutral-300 hover:text-white hover:bg-neutral-900 border border-neutral-700/50'
          }`}
        >
          <Heart className={`w-4 h-4 ${wishlisted ? 'fill-rose-500' : ''}`} />
        </button>
      </div>

      {/* Body Information */}
      <div className="flex-1 p-3.5 sm:p-4 flex flex-col justify-between">
        <div>
          {/* Category & Rating Row (Zero-Pill discipline) */}
          <div className="flex items-center justify-between text-xs text-neutral-400 mb-1.5">
            <span className="uppercase tracking-wider font-mono text-[10px] sm:text-xs text-neutral-400 truncate">
              {product.category}
            </span>
            <div className="flex items-center gap-1 text-amber-400 font-mono text-[11px] shrink-0">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span>{product.rating}</span>
              <span className="text-neutral-500">({product.reviewCount})</span>
            </div>
          </div>

          {/* Product Title */}
          <h3 
            onClick={() => setSelectedProduct(product)}
            className="text-sm sm:text-base font-semibold text-neutral-100 hover:text-emerald-400 transition-colors line-clamp-2 cursor-pointer leading-snug mb-2"
          >
            {product.name}
          </h3>

          {/* Price Row */}
          <div className="flex items-baseline gap-2 mb-3">
            <span className="text-lg sm:text-xl font-bold text-white font-mono-numbers tracking-tight">
              ৳{product.price.toLocaleString()}
            </span>
            {product.originalPrice > product.price && (
              <span className="text-xs text-neutral-500 line-through font-mono-numbers">
                ৳{product.originalPrice.toLocaleString()}
              </span>
            )}
            <span className="text-[11px] text-emerald-400 font-mono font-medium ml-auto hidden xs:inline">
              Save ৳{(product.originalPrice - product.price).toLocaleString()}
            </span>
          </div>
        </div>

        {/* Action Buttons: Add to Cart & Buy Now */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-neutral-800/80">
          <button
            type="button"
            onClick={() => addToCart(product, 1, false)}
            className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-neutral-800 hover:bg-neutral-700 active:scale-95 text-neutral-200 hover:text-white text-xs font-semibold rounded-lg transition-colors border border-neutral-700/60"
            title="Add to Cart"
          >
            <ShoppingCart className="w-3.5 h-3.5 text-emerald-400" />
            <span className="truncate">Add to Cart</span>
          </button>

          <button
            type="button"
            onClick={() => initiateBuyNow(product, 1)}
            className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-neutral-950 text-xs font-bold rounded-lg transition-all shadow-[0_0_10px_rgba(16,185,129,0.25)]"
            title="Instant Checkout"
          >
            <Zap className="w-3.5 h-3.5 fill-neutral-950" />
            <span className="truncate">Buy Now</span>
          </button>
        </div>
      </div>
    </div>
  );
};
