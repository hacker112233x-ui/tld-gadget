import React from 'react';
import { useShop } from '../context/ShopContext';
import { ProductCategory } from '../types';
import { PRODUCTS } from '../data/products';
import { SlidersHorizontal, Sparkles, X } from 'lucide-react';

const CATEGORIES: ProductCategory[] = [
  'All',
  'Gaming Finger Sleeves',
  'Esports Gaming Headphones',
  'Gaming Cooler',
  'COMBO',
  'Charger Adapter And Cable',
  'Gaming TWS',
  'Cooler Clips and Heat Sink Magnetic Plate',
  'Power Bank',
];

export const CategoryFilterBar: React.FC = () => {
  const { 
    selectedCategory, 
    setSelectedCategory, 
    sortBy, 
    setSortBy, 
    searchQuery, 
    setSearchQuery 
  } = useShop();

  const getCategoryCount = (category: ProductCategory) => {
    if (category === 'All') return PRODUCTS.length;
    return PRODUCTS.filter(p => p.category === category).length;
  };

  return (
    <div id="catalog-section" className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pt-6 sm:pt-8 pb-4 w-full box-border overflow-hidden">
      {/* Search status indicator if searching */}
      {searchQuery && (
        <div className="mb-4 flex items-center justify-between bg-neutral-900 border border-neutral-800 rounded-lg p-3">
          <div className="flex items-center gap-2 text-sm text-neutral-300">
            <span className="text-neutral-400">Search results for:</span>
            <span className="font-semibold text-emerald-400">"{searchQuery}"</span>
          </div>
          <button
            type="button"
            onClick={() => setSearchQuery('')}
            className="flex items-center gap-1 text-xs text-neutral-400 hover:text-white px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
            <span>Clear Filter</span>
          </button>
        </div>
      )}

      {/* Row with Categories and Sorting */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-neutral-800/80 pb-4 max-w-full">
        {/* Horizontal Scrollable Categories */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1 max-w-full">
          {CATEGORIES.map((category) => {
            const isSelected = selectedCategory === category;
            const count = getCategoryCount(category);

            return (
              <button
                key={category}
                type="button"
                onClick={() => setSelectedCategory(category)}
                className={`whitespace-nowrap px-3.5 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all duration-150 shrink-0 flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
                  isSelected
                    ? 'bg-emerald-500 text-neutral-950 font-bold shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                    : 'bg-neutral-900 text-neutral-300 hover:text-white hover:bg-neutral-800 border border-neutral-800/80'
                }`}
              >
                <span>{category}</span>
                <span 
                  className={`text-[11px] font-mono px-1.5 py-0.2 rounded ${
                    isSelected ? 'bg-neutral-950/20 text-neutral-950 font-bold' : 'bg-neutral-800 text-neutral-400'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Sort Dropdown */}
        <div className="flex items-center justify-between md:justify-end gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <SlidersHorizontal className="w-3.5 h-3.5 text-neutral-500" />
            <span className="hidden sm:inline">Sort:</span>
          </div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-neutral-900 border border-neutral-800 text-neutral-200 text-xs sm:text-sm rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
          >
            <option value="featured">Featured Essentials</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="rating">Top Customer Rated</option>
            <option value="discount">Biggest Discount</option>
          </select>
        </div>
      </div>
    </div>
  );
};
