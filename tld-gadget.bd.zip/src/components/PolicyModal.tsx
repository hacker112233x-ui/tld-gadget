import React from 'react';
import { useShop, STORE_PHONE_DISPLAY } from '../context/ShopContext';
import { X, ShieldCheck, Truck, RotateCcw, FileText } from 'lucide-react';

export const PolicyModal: React.FC = () => {
  const { activePolicy, setActivePolicy } = useShop();

  if (!activePolicy) return null;

  const renderContent = () => {
    switch (activePolicy) {
      case 'return':
        return {
          icon: RotateCcw,
          title: '7 Days Replacement & Return Policy',
          body: (
            <div className="space-y-4 text-xs sm:text-sm text-neutral-300">
              <p>
                At <strong>TLD GADGET.BD</strong>, we stand behind the quality of our mobile gaming hardware. If your product arrives damaged or with manufacturing defects, you are eligible for an instant replacement.
              </p>
              <h4 className="font-bold text-white uppercase text-xs font-mono">Eligibility Conditions:</h4>
              <ul className="list-disc pl-5 space-y-1.5 text-neutral-300">
                <li>Claim must be submitted within 7 days from the delivery date.</li>
                <li>Product must include the original packaging, accessories, manuals, and invoice.</li>
                <li>Issues caused by physical drops, liquid submersion, or misuse are not covered.</li>
              </ul>
              <h4 className="font-bold text-white uppercase text-xs font-mono">How to Request:</h4>
              <p>
                Send a photo/video showing the issue directly to our official WhatsApp hotline (<strong>{STORE_PHONE_DISPLAY}</strong>) with your Order ID. Our customer representative will dispatch a replacement parcel promptly.
              </p>
            </div>
          )
        };
      case 'shipping':
        return {
          icon: Truck,
          title: 'Nationwide Delivery & Shipping Policy',
          body: (
            <div className="space-y-4 text-xs sm:text-sm text-neutral-300">
              <p>
                We deliver gaming gadgets across all 64 districts in Bangladesh with reliable courier partners (Steadfast, Pathao, RedX, and eCourier).
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
                  <span className="text-emerald-400 font-bold block text-sm mb-1">Inside Dhaka City</span>
                  <p className="text-xs text-neutral-400">Delivery charge: ৳60<br />Delivery timeline: 24 to 48 Hours.</p>
                </div>
                <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
                  <span className="text-emerald-400 font-bold block text-sm mb-1">Outside Dhaka City</span>
                  <p className="text-xs text-neutral-400">Delivery charge: ৳120<br />Delivery timeline: 2 to 3 Business Days.</p>
                </div>
              </div>
              <p className="text-xs text-neutral-400">
                ⭐ Orders totaling <strong>৳2,000 or more</strong> receive automatic <strong>FREE DELIVERY</strong> anywhere in Bangladesh!
              </p>
            </div>
          )
        };
      case 'privacy':
        return {
          icon: ShieldCheck,
          title: 'Privacy Policy & Customer Security',
          body: (
            <div className="space-y-4 text-xs sm:text-sm text-neutral-300">
              <p>
                TLD GADGET.BD values your privacy. We collect your delivery information (Name, Phone Number, Address) strictly to fulfill your orders and deliver parcels safely.
              </p>
              <p>
                We do not sell, rent, or distribute your personal contact details to any third-party marketing companies. All checkout information is transmitted over encrypted protocols.
              </p>
              <p>
                For questions regarding stored customer data, please reach out to our team at support@tldgadget.bd.
              </p>
            </div>
          )
        };
      case 'terms':
      default:
        return {
          icon: FileText,
          title: 'Terms of Service',
          body: (
            <div className="space-y-4 text-xs sm:text-sm text-neutral-300">
              <p>
                By placing an order on TLD GADGET.BD, you agree to receive parcel confirmation calls or SMS notifications to ensure smooth courier delivery.
              </p>
              <p>
                Customers choosing Cash on Delivery are requested to verify and accept parcels respectfully. Unreasonable delivery rejections incur courier operational costs.
              </p>
              <p>
                Prices are displayed in Bangladeshi Taka (৳) and include applicable trade taxes.
              </p>
            </div>
          )
        };
    }
  };

  const { icon: Icon, title, body } = renderContent();

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div 
        className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-neutral-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <Icon className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white font-display uppercase tracking-wide">
              {title}
            </h3>
          </div>
          <button
            type="button"
            onClick={() => setActivePolicy(null)}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="max-h-[60vh] overflow-y-auto pr-1">
          {body}
        </div>

        <div className="mt-6 pt-4 border-t border-neutral-800 flex justify-end">
          <button
            type="button"
            onClick={() => setActivePolicy(null)}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
