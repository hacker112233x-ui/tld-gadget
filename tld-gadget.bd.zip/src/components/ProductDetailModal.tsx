import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { getProductImageUrl, coolerImg } from '../data/products';
import { 
  X, 
  ArrowLeft,
  ShoppingCart, 
  Zap, 
  Heart, 
  Star, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Check, 
  Package, 
  Layers
} from 'lucide-react';

export const ProductDetailModal: React.FC = () => {
  const { 
    selectedProduct, 
    setSelectedProduct, 
    addToCart, 
    initiateBuyNow, 
    toggleWishlist, 
    isWishlisted 
  } = useShop();

  const [qty, setQty] = useState(1);

  if (!selectedProduct) return null;

  const product = selectedProduct;
  const wishlisted = isWishlisted(product.id);
  const isStockLow = product.stockCount <= 5;

  const handleAddToCart = () => {
    addToCart(product, qty, true);
    setSelectedProduct(null);
  };

  const handleBuyNow = () => {
    initiateBuyNow(product, qty);
    setSelectedProduct(null);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/85 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6">
      <div 
        className="relative w-full max-w-4xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Prominent Mobile-Friendly Navigation Bar with Back Button */}
        <div className="sticky top-0 z-30 flex items-center justify-between px-3.5 py-2.5 sm:px-6 sm:py-3.5 bg-neutral-950/95 border-b border-neutral-800/90 backdrop-blur-md">
          <button
            type="button"
            onClick={() => setSelectedProduct(null)}
            className="inline-flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 active:scale-95 text-emerald-400 hover:text-emerald-300 border border-emerald-500/40 hover:border-emerald-400 transition-all text-xs sm:text-sm font-bold group shadow-sm cursor-pointer"
            aria-label="পিছনে যান (Back)"
          >
            <ArrowLeft className="w-4 h-4 text-emerald-400 group-hover:-translate-x-1 transition-transform" />
            <span className="font-display tracking-wide flex items-center gap-1.5">
              <span className="font-bold text-white">← পিছনে যান</span>
              <span className="text-neutral-500 hidden sm:inline">(Back to Store)</span>
            </span>
          </button>

          <div className="flex items-center gap-2 sm:gap-3">
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              অফিশিয়াল গ্যারান্টি
            </span>
            <button
              type="button"
              onClick={() => setSelectedProduct(null)}
              className="p-2 text-neutral-400 hover:text-white bg-neutral-900 hover:bg-neutral-800 rounded-lg transition-colors border border-neutral-800 cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
          {/* Left Column: Media & Visuals */}
          <div className="relative bg-neutral-950 p-4 sm:p-6 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-neutral-800">
            <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden border border-neutral-800 bg-neutral-900">
              <img
                src={getProductImageUrl(product.image)}
                alt={product.name}
                onError={(e) => {
                  (e.target as HTMLImageElement).src = coolerImg;
                }}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center"
              />
              {product.discountPercent > 0 && (
                <span className="absolute top-3 left-3 px-2 py-0.5 text-xs font-mono font-bold bg-rose-600 text-white rounded">
                  -{product.discountPercent}% OFF
                </span>
              )}
            </div>

            {/* Quick Guarantees beneath image */}
            <div className="mt-6 w-full grid grid-cols-3 gap-2 text-center text-xs text-neutral-400">
              <div className="p-2 rounded bg-neutral-900/60 border border-neutral-800">
                <Truck className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
                <span className="text-[11px] block leading-tight">24-48h Delivery</span>
              </div>
              <div className="p-2 rounded bg-neutral-900/60 border border-neutral-800">
                <RotateCcw className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
                <span className="text-[11px] block leading-tight">7 Days Return</span>
              </div>
              <div className="p-2 rounded bg-neutral-900/60 border border-neutral-800">
                <ShieldCheck className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
                <span className="text-[11px] block leading-tight">100% Genuine</span>
              </div>
            </div>
          </div>

          {/* Right Column: Specs & Purchase Controller */}
          <div className="p-6 sm:p-8 flex flex-col justify-between max-h-[85vh] overflow-y-auto">
            <div>
              {/* Category & Status */}
              <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
                <span className="font-mono uppercase text-emerald-400 font-semibold tracking-wider">
                  {product.category}
                </span>
                <div className="flex items-center gap-1.5 font-mono text-amber-400">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  <span className="font-bold">{product.rating}</span>
                  <span className="text-neutral-500">({product.reviewCount} customer reviews)</span>
                </div>
              </div>

              {/* Title */}
              <h2 className="text-xl sm:text-2xl font-bold text-white font-display uppercase tracking-tight mb-2 leading-snug">
                {product.name}
              </h2>

              {/* Tagline */}
              <p className="text-xs sm:text-sm text-neutral-400 mb-4 font-medium italic">
                "{product.tagline}"
              </p>

              {/* Price & Stock */}
              <div className="flex items-baseline gap-3 p-3 bg-neutral-950/70 rounded-xl border border-neutral-800 mb-5">
                <span className="text-2xl sm:text-3xl font-bold text-white font-mono-numbers">
                  ৳{product.price.toLocaleString()}
                </span>
                {product.originalPrice > product.price && (
                  <span className="text-sm text-neutral-500 line-through font-mono-numbers">
                    ৳{product.originalPrice.toLocaleString()}
                  </span>
                )}
                <div className="ml-auto flex items-center gap-1.5">
                  <span className={`h-2 w-2 rounded-full ${isStockLow ? 'bg-amber-400' : 'bg-emerald-400'} animate-pulse`} />
                  <span className={`text-xs font-mono font-medium ${isStockLow ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {isStockLow ? `Only ${product.stockCount} left in stock` : 'In Stock (Ready to dispatch)'}
                  </span>
                </div>
              </div>

              {/* Description */}
              <div className="mb-5">
                <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
                  {product.description}
                </p>
              </div>

              {/* Key Features */}
              <div className="mb-5">
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2.5 font-mono">
                  Key Highlights
                </h4>
                <ul className="space-y-1.5">
                  {product.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-neutral-300">
                      <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Technical Specifications */}
              <div className="mb-5">
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2.5 font-mono flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-emerald-400" />
                  Technical Specifications
                </h4>
                <div className="bg-neutral-950/60 rounded-lg border border-neutral-800 divide-y divide-neutral-800 text-xs">
                  {Object.entries(product.specs).map(([key, value]) => (
                    <div key={key} className="flex justify-between py-2 px-3">
                      <span className="text-neutral-400 font-medium">{key}</span>
                      <span className="text-neutral-200 font-mono text-right">{value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* In The Box */}
              <div className="mb-6">
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2 font-mono flex items-center gap-1.5">
                  <Package className="w-3.5 h-3.5 text-emerald-400" />
                  In the Box
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {product.inTheBox.map((item, idx) => (
                    <span key={idx} className="text-xs text-neutral-300 bg-neutral-800 px-2.5 py-1 rounded">
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Bar with Quantity Picker */}
            <div className="pt-4 border-t border-neutral-800 space-y-3">
              <div className="flex items-center gap-3">
                {/* Quantity adjustment */}
                <div className="flex items-center border border-neutral-700 bg-neutral-950 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setQty(Math.max(1, qty - 1))}
                    className="px-3 py-2 text-neutral-400 hover:text-white transition-colors"
                  >
                    -
                  </button>
                  <span className="px-3 py-2 text-sm font-mono font-bold text-white">
                    {qty}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQty(Math.min(product.stockCount, qty + 1))}
                    className="px-3 py-2 text-neutral-400 hover:text-white transition-colors"
                  >
                    +
                  </button>
                </div>

                {/* Wishlist toggle */}
                <button
                  type="button"
                  onClick={() => toggleWishlist(product.id)}
                  className={`p-2.5 rounded-lg border transition-colors ${
                    wishlisted 
                      ? 'border-rose-500/50 bg-rose-500/10 text-rose-500' 
                      : 'border-neutral-700 bg-neutral-800 text-neutral-300 hover:text-white'
                  }`}
                  title={wishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
                >
                  <Heart className={`w-5 h-5 ${wishlisted ? 'fill-rose-500' : ''}`} />
                </button>

                {/* Add to Cart */}
                <button
                  type="button"
                  onClick={handleAddToCart}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 bg-neutral-800 hover:bg-neutral-700 active:scale-98 text-white font-semibold text-sm rounded-lg border border-neutral-700 transition-colors"
                >
                  <ShoppingCart className="w-4 h-4 text-emerald-400" />
                  <span>Add to Cart</span>
                </button>
              </div>

              {/* Instant Buy Now */}
              <button
                type="button"
                onClick={handleBuyNow}
                className="w-full flex items-center justify-center gap-2 py-3 px-6 bg-emerald-500 hover:bg-emerald-400 active:scale-98 text-neutral-950 font-bold text-sm rounded-lg shadow-[0_0_20px_rgba(16,185,129,0.35)] transition-all font-display uppercase tracking-wider"
              >
                <Zap className="w-4 h-4 fill-neutral-950" />
                <span>Buy Now • ৳{(product.price * qty).toLocaleString()}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
