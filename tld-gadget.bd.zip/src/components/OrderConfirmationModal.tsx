import React from 'react';
import { useShop, STORE_PHONE_NUMBER } from '../context/ShopContext';
import { 
  CheckCircle2, 
  X, 
  Package, 
  Truck, 
  Phone, 
  MessageCircle, 
  Download, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export const OrderConfirmationModal: React.FC = () => {
  const { lastOrder, setLastOrder } = useShop();

  if (!lastOrder) return null;

  const order = lastOrder;

  // WhatsApp message creation
  const waMessage = encodeURIComponent(
    `Hello TLD GADGET.BD!\nI have placed Order #${order.orderId} on your website.\n\n` +
    `Items:\n` +
    order.items.map(i => `- ${i.product.name} (x${i.quantity})`).join('\n') +
    `\n\nTotal: ৳${order.totalAmount}` +
    `\nCustomer: ${order.shippingDetails.customerName}` +
    `\nPhone: ${order.shippingDetails.phone}` +
    `\nAddress: ${order.shippingDetails.address}` +
    `\nPayment: ${order.shippingDetails.paymentMethod.toUpperCase()}` +
    (order.shippingDetails.trxId ? `\nTrxID: ${order.shippingDetails.trxId}` : '') +
    `\n\nPlease confirm dispatch!`
  );

  const cleanPhone = STORE_PHONE_NUMBER.replace('+', '');
  const waLink = `https://wa.me/${cleanPhone}?text=${waMessage}`;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6">
      <div 
        className="relative w-full max-w-xl bg-neutral-900 border border-emerald-500/40 rounded-2xl shadow-[0_0_50px_rgba(16,185,129,0.2)] overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Success Badge */}
        <div className="p-6 bg-gradient-to-b from-emerald-950/50 to-neutral-900 border-b border-neutral-800 text-center relative">
          <button
            type="button"
            onClick={() => setLastOrder(null)}
            className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 flex items-center justify-center mx-auto mb-3 shadow-[0_0_20px_rgba(16,185,129,0.4)]">
            <CheckCircle2 className="w-9 h-9 text-emerald-400" />
          </div>

          <span className="text-xs font-mono font-bold text-emerald-400 tracking-widest uppercase">
            Order Confirmed
          </span>
          <h2 className="text-2xl font-bold text-white font-display uppercase mt-1">
            Thank You for Your Order!
          </h2>
          <p className="text-xs text-neutral-400 mt-1">
            Order ID: <span className="font-mono font-bold text-emerald-400">#{order.orderId}</span> · {order.createdAt}
          </p>
        </div>

        {/* Order Details & Summary */}
        <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
          {/* Estimated Delivery Status */}
          <div className="p-3.5 bg-neutral-950 rounded-xl border border-neutral-800 flex items-start gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div className="text-xs">
              <strong className="text-white block font-semibold text-sm">
                Estimated Delivery: {order.shippingDetails.city === 'dhaka' ? '24 - 48 Hours' : '2 - 3 Days'}
              </strong>
              <span className="text-neutral-400">
                Our logistics partner will call you at <span className="text-emerald-300 font-mono font-bold">{order.shippingDetails.phone}</span> prior to delivery.
              </span>
            </div>
          </div>

          {/* Customer & Address Details */}
          <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800 text-xs space-y-2">
            <h4 className="font-mono font-semibold uppercase text-neutral-400">Shipping Details</h4>
            <div className="grid grid-cols-2 gap-2 text-neutral-300">
              <div>
                <span className="text-neutral-500 block text-[11px]">Recipient:</span>
                <span className="font-semibold text-white">{order.shippingDetails.customerName}</span>
              </div>
              <div>
                <span className="text-neutral-500 block text-[11px]">Phone:</span>
                <span className="font-mono text-emerald-300">{order.shippingDetails.phone}</span>
              </div>
              <div className="col-span-2">
                <span className="text-neutral-500 block text-[11px]">Address:</span>
                <span className="text-neutral-200">{order.shippingDetails.address}</span>
              </div>
              <div>
                <span className="text-neutral-500 block text-[11px]">Payment Method:</span>
                <span className="font-mono font-bold uppercase text-white">
                  {order.shippingDetails.paymentMethod === 'cod' ? 'Cash on Delivery (COD)' : order.shippingDetails.paymentMethod.toUpperCase()}
                </span>
              </div>
              {order.shippingDetails.trxId && (
                <div>
                  <span className="text-neutral-500 block text-[11px]">Transaction ID:</span>
                  <span className="font-mono text-amber-400">{order.shippingDetails.trxId}</span>
                </div>
              )}
            </div>
          </div>

          {/* Itemized summary */}
          <div className="space-y-2 text-xs">
            <h4 className="font-mono font-semibold uppercase text-neutral-400">Order Items</h4>
            <div className="divide-y divide-neutral-800 bg-neutral-950 rounded-xl border border-neutral-800 p-3">
              {order.items.map((item) => (
                <div key={item.product.id} className="py-2 flex items-center justify-between first:pt-0 last:pb-0">
                  <div className="truncate pr-2">
                    <span className="font-semibold text-neutral-200">{item.product.name}</span>
                    <span className="text-neutral-500 block text-[11px]">Qty: {item.quantity} × ৳{item.product.price.toLocaleString()}</span>
                  </div>
                  <span className="font-mono-numbers font-bold text-white shrink-0">
                    ৳{(item.product.price * item.quantity).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Total bill recap */}
          <div className="flex justify-between items-center p-4 bg-emerald-950/20 border border-emerald-500/30 rounded-xl">
            <span className="text-sm font-bold text-white font-display uppercase tracking-wider">
              Total Amount
            </span>
            <span className="text-xl font-bold text-emerald-400 font-mono-numbers">
              ৳{order.totalAmount.toLocaleString()}
            </span>
          </div>

          {/* Action CTAs */}
          <div className="space-y-2.5 pt-2">
            {/* Direct WhatsApp Confirmation Button */}
            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl transition-all shadow-[0_0_15px_rgba(16,185,129,0.3)]"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Direct WhatsApp Instant Confirmation</span>
            </a>

            {/* Continue Shopping Button */}
            <button
              type="button"
              onClick={() => setLastOrder(null)}
              className="w-full py-2.5 px-4 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-xs rounded-xl transition-colors"
            >
              Continue Shopping
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
