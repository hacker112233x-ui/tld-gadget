import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { getProductImageUrl, coolerImg } from '../data/products';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  ArrowRight, 
  Tag, 
  Truck, 
  Check, 
  ShieldCheck 
} from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    removeFromCart,
    updateCartQuantity,
    subtotal,
    deliveryFee,
    deliveryZone,
    setDeliveryZone,
    freeDeliveryThreshold,
    freeDeliveryProgress,
    promoCode,
    promoDiscount,
    promoError,
    applyPromoCode,
    removePromoCode,
    totalAmount,
    setIsCheckoutOpen
  } = useShop();

  const [inputCode, setInputCode] = useState('');

  if (!isCartOpen) return null;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (applyPromoCode(inputCode)) {
      setInputCode('');
    }
  };

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const amountNeededForFreeDelivery = Math.max(0, freeDeliveryThreshold - subtotal);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        onClick={() => setIsCartOpen(false)}
        className="absolute inset-0 bg-neutral-950/75 backdrop-blur-sm transition-opacity" 
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-0 sm:pl-8">
        <div className="w-full max-w-md sm:w-md bg-neutral-900 border-l border-neutral-800 shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white font-display uppercase tracking-wider">
                  Your Cart
                </h2>
                <span className="text-xs font-mono text-neutral-400">
                  {cart.length} unique item{cart.length !== 1 ? 's' : ''}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsCartOpen(false)}
              className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition-colors"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Progress Tracker */}
          {cart.length > 0 && (
            <div className="bg-neutral-950/90 border-b border-neutral-800 p-3.5">
              <div className="flex items-center justify-between text-xs mb-1.5 font-mono">
                <span className="text-neutral-300 flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-emerald-400" />
                  {amountNeededForFreeDelivery === 0 
                    ? <strong className="text-emerald-400 font-bold">You unlocked FREE Delivery! 🚚</strong>
                    : <>Add <strong>৳{amountNeededForFreeDelivery.toLocaleString()}</strong> more for FREE Delivery</>
                  }
                </span>
                <span className="text-neutral-500 font-bold">{freeDeliveryProgress}%</span>
              </div>
              <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-emerald-500 transition-all duration-300 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.8)]"
                  style={{ width: `${freeDeliveryProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-neutral-800/80 border border-neutral-700 flex items-center justify-center text-neutral-500">
                  <ShoppingBag className="w-8 h-8 text-neutral-500" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-semibold text-white">Your cart is empty</h3>
                  <p className="text-xs text-neutral-400 max-w-xs">
                    Equip your setup with tournament-grade finger sleeves, semiconductor coolers, and low-latency audio.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsCartOpen(false)}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-lg transition-all"
                >
                  Browse Gaming Gear
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div 
                  key={item.product.id}
                  className="flex gap-3 p-3 bg-neutral-950/70 rounded-xl border border-neutral-800 hover:border-neutral-700 transition-colors"
                >
                  <img
                    src={getProductImageUrl(item.product.image)}
                    alt={item.product.name}
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = coolerImg;
                    }}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-lg bg-neutral-900 border border-neutral-800 shrink-0"
                  />

                  <div className="flex-1 flex flex-col justify-between min-w-0">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-xs sm:text-sm font-semibold text-neutral-100 line-clamp-2 leading-tight">
                          {item.product.name}
                        </h4>
                        <button
                          type="button"
                          onClick={() => removeFromCart(item.product.id)}
                          className="p-1 text-neutral-500 hover:text-rose-400 transition-colors shrink-0"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <span className="text-[10px] font-mono uppercase text-emerald-400">
                        {item.product.category}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-2 pt-1 border-t border-neutral-900">
                      <span className="text-sm font-bold text-white font-mono-numbers">
                        ৳{(item.product.price * item.quantity).toLocaleString()}
                      </span>

                      {/* Quantity Selector */}
                      <div className="flex items-center border border-neutral-700 bg-neutral-900 rounded-md">
                        <button
                          type="button"
                          onClick={() => updateCartQuantity(item.product.id, -1)}
                          className="px-2 py-0.5 text-neutral-400 hover:text-white transition-colors"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 py-0.5 text-xs font-mono font-bold text-neutral-200">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => updateCartQuantity(item.product.id, 1)}
                          className="px-2 py-0.5 text-neutral-400 hover:text-white transition-colors"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Bill Breakdown */}
          {cart.length > 0 && (
            <div className="p-4 sm:p-5 bg-neutral-950 border-t border-neutral-800 space-y-3.5">
              {/* Delivery Zone Selector */}
              <div>
                <label className="block text-[11px] font-mono text-neutral-400 mb-1.5 uppercase font-medium">
                  Delivery Destination:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setDeliveryZone('dhaka')}
                    className={`p-2 text-xs font-medium rounded-lg border text-center transition-all ${
                      deliveryZone === 'dhaka'
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-300 font-semibold'
                        : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:border-neutral-700'
                    }`}
                  >
                    Inside Dhaka (৳60)
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeliveryZone('outside_dhaka')}
                    className={`p-2 text-xs font-medium rounded-lg border text-center transition-all ${
                      deliveryZone === 'outside_dhaka'
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-300 font-semibold'
                        : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:border-neutral-700'
                    }`}
                  >
                    Outside Dhaka (৳120)
                  </button>
                </div>
              </div>

              {/* Promo Code Input */}
              <form onSubmit={handleApplyCoupon} className="space-y-1">
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-2.5" />
                    <input
                      type="text"
                      value={inputCode}
                      onChange={(e) => setInputCode(e.target.value)}
                      placeholder="Coupon: TLD10, GAMERBD"
                      className="w-full bg-neutral-900 border border-neutral-800 text-xs text-white rounded-lg py-2 pl-8 pr-2 focus:outline-none focus:border-emerald-500 uppercase font-mono"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white text-xs font-semibold rounded-lg transition-colors shrink-0"
                  >
                    Apply
                  </button>
                </div>

                {promoDiscount > 0 && (
                  <div className="flex items-center justify-between text-xs text-emerald-400 font-mono pt-1">
                    <span>Coupon Applied (-৳{promoDiscount.toLocaleString()})</span>
                    <button 
                      type="button" 
                      onClick={removePromoCode}
                      className="text-neutral-400 hover:text-rose-400 underline"
                    >
                      Remove
                    </button>
                  </div>
                )}

                {promoError && (
                  <p className="text-[11px] text-rose-400 font-mono">{promoError}</p>
                )}
              </form>

              {/* Bill Details */}
              <div className="space-y-1.5 pt-2 border-t border-neutral-800/80 text-xs">
                <div className="flex justify-between text-neutral-400">
                  <span>Subtotal</span>
                  <span className="font-mono-numbers text-neutral-200">৳{subtotal.toLocaleString()}</span>
                </div>

                <div className="flex justify-between text-neutral-400">
                  <span>Delivery Charge</span>
                  <span className="font-mono-numbers text-neutral-200">
                    {deliveryFee === 0 ? <span className="text-emerald-400 font-bold">FREE</span> : `৳${deliveryFee}`}
                  </span>
                </div>

                {promoDiscount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount</span>
                    <span className="font-mono-numbers">-৳{promoDiscount.toLocaleString()}</span>
                  </div>
                )}

                <div className="flex justify-between text-sm sm:text-base font-bold text-white pt-2 border-t border-neutral-800">
                  <span className="font-display uppercase tracking-wider">Total Bill</span>
                  <span className="text-emerald-400 font-mono-numbers text-lg">
                    ৳{totalAmount.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Proceed to Checkout Button */}
              <button
                type="button"
                onClick={handleProceedToCheckout}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-500 hover:bg-emerald-400 active:scale-98 text-neutral-950 font-bold text-sm rounded-lg shadow-[0_0_15px_rgba(16,185,129,0.3)] transition-all font-display uppercase tracking-wider"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
