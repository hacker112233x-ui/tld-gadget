import React, { useState, useEffect, useRef } from 'react';
import { useShop } from '../context/ShopContext';
import { PRODUCTS, getProductImageUrl, heroBannerImg, sleevesImg, twsImg, comboImg } from '../data/products';
import { ChevronLeft, ChevronRight, Zap, ShieldCheck } from 'lucide-react';
import { ProductCategory } from '../types';

interface HeroSlide {
  id: number;
  badge: string;
  tagline: string;
  title: string;
  subtitle: string;
  price: number;
  originalPrice: number;
  categoryTarget: ProductCategory;
  productId: string;
  image: string;
  discountBadge: string;
}

const HERO_SLIDES: HeroSlide[] = [
  {
    id: 1,
    badge: 'বেস্ট গেমিং এ্যাকসেসরিজ',
    tagline: '15W FAST SEMICONDUCTOR COOLING',
    title: 'Memo CX07 Magnetic Phone Cooler Fan',
    subtitle: '15W ম্যাগনেটিক কুলার ফ্যান — হেভি গেমিংয়ে ফোন রাখে সম্পূর্ণ বরফ ঠান্ডা।',
    price: 1150,
    originalPrice: 1450,
    categoryTarget: 'Gaming Cooler',
    productId: 'memo-cx07-cooler',
    image: 'https://i.ibb.co/20qC2vcB/0b2bd6d3-187a-4a32-bc07-00d9affab04b.jpg',
    discountBadge: '২১% ছাড়'
  },
  {
    id: 2,
    badge: 'টুর্নামেন্ট কম্বো',
    tagline: 'ALL-IN-ONE ESPORTS LOADOUT',
    title: 'Esports Dominator 5-in-1 Ultimate Combo',
    subtitle: 'মেমো CX07 কুলার + মেকানিক্যাল ট্রিগার + ৪টি স্লিভস + ইভিএ হার্ডকেস।',
    price: 2150,
    originalPrice: 2850,
    categoryTarget: 'COMBO',
    productId: 'tld-tournament-combo-pro',
    image: comboImg,
    discountBadge: '২৫% মেগা সেভ'
  },
  {
    id: 3,
    badge: '৩৫ms আল্ট্রা লো ল্যাগ',
    tagline: 'SPATIAL FOOTSTEP AUDIO ENGINE',
    title: 'TLD CyberPods X-15 Gaming TWS Earbuds',
    subtitle: 'PUBG ও FreeFire-এ নিখুঁত ফুটস্টেপ ও রিলোড সাউন্ড ১৩mm টাইটানিয়াম ড্রাইভার দিয়ে।',
    price: 1850,
    originalPrice: 2450,
    categoryTarget: 'Gaming TWS',
    productId: 'tld-cyberpods-x15',
    image: twsImg,
    discountBadge: '৳৬০০ ছাড়'
  },
  {
    id: 4,
    badge: '১০০% সিলভার ফাইবার',
    tagline: '24-NEEDLE ZERO TOUCH LAG',
    title: 'TLD Carbon-Silver Pro Gaming Sleeves',
    subtitle: '২৪-নিডেল সুপারকন্ডাক্টর সিলভার ফাইবার — আঙুলের ঘাম রোধ করে দেয় নির্ভুল এইম।',
    price: 220,
    originalPrice: 280,
    categoryTarget: 'Gaming Finger Sleeves',
    productId: 'tld-sleeves-v4',
    image: sleevesImg,
    discountBadge: 'হট সেলার'
  }
];

export const HeroBanner: React.FC = () => {
  const { setSelectedProduct, initiateBuyNow } = useShop();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Touch and drag swipe state
  const touchStartXRef = useRef<number | null>(null);
  const touchEndXRef = useRef<number | null>(null);

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 5500);
    return () => clearInterval(timer);
  }, [isPaused]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndXRef.current = e.touches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartXRef.current || !touchEndXRef.current) return;
    const distance = touchStartXRef.current - touchEndXRef.current;
    const minSwipeDistance = 40;

    if (distance > minSwipeDistance) {
      nextSlide();
    } else if (distance < -minSwipeDistance) {
      prevSlide();
    }
    touchStartXRef.current = null;
    touchEndXRef.current = null;
  };

  const slide = HERO_SLIDES[currentSlide];

  const handleBuyNow = () => {
    const product = PRODUCTS.find((p) => p.id === slide.productId);
    if (product) {
      initiateBuyNow(product, 1);
    }
  };

  const handleViewDetails = () => {
    const product = PRODUCTS.find((p) => p.id === slide.productId);
    if (product) {
      setSelectedProduct(product);
    }
  };

  return (
    <section 
      className="relative w-full max-w-7xl mx-auto px-2.5 sm:px-4 lg:px-8 pt-2.5 pb-1 box-border overflow-hidden"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div className="relative w-full overflow-hidden rounded-xl sm:rounded-2xl border border-neutral-800 bg-neutral-900 shadow-xl shadow-emerald-950/20 box-border">
        {/* Sleek Outer/Inner Left Navigation Arrow ("❮") vertically centered */}
        <button
          type="button"
          onClick={prevSlide}
          aria-label="Previous Slide (❮)"
          className="absolute left-1 sm:left-2.5 top-1/2 -translate-y-1/2 z-30 w-7 h-7 sm:w-9 sm:h-9 rounded-full bg-neutral-950/85 hover:bg-neutral-900 active:scale-90 text-white hover:text-emerald-400 border border-neutral-700/80 hover:border-emerald-500/60 backdrop-blur-md shadow-md flex items-center justify-center transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
        >
          <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5 -ml-0.5" />
        </button>

        {/* Sleek Outer/Inner Right Navigation Arrow ("❯") vertically centered */}
        <button
          type="button"
          onClick={nextSlide}
          aria-label="Next Slide (❯)"
          className="absolute right-1 sm:right-2.5 top-1/2 -translate-y-1/2 z-30 w-7 h-7 sm:w-9 sm:h-9 rounded-full bg-neutral-950/85 hover:bg-neutral-900 active:scale-90 text-white hover:text-emerald-400 border border-neutral-700/80 hover:border-emerald-500/60 backdrop-blur-md shadow-md flex items-center justify-center transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
        >
          <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5 -mr-0.5" />
        </button>

        {/* Compact 2-Column Horizontal Flex Row (Side-by-Side on ALL screens) */}
        <div className="flex flex-row items-stretch w-full min-h-[170px] sm:min-h-[220px] md:min-h-[260px] max-h-[300px] sm:max-h-[320px]">
          {/* Left Column (approx 50%): Category Badges, Title, short detail, Price tag, and Action Buttons */}
          <div className="w-1/2 p-2.5 sm:p-5 md:p-6 pl-8 sm:pl-12 flex flex-col justify-center gap-1 sm:gap-2 z-20 bg-gradient-to-r from-neutral-950 via-neutral-950/95 to-neutral-900/90 box-border min-w-0">
            {/* Category Badges */}
            <div className="flex flex-wrap items-center gap-1 sm:gap-1.5">
              <span className="inline-flex items-center gap-1 text-[9px] sm:text-[11px] font-mono font-bold uppercase text-emerald-400 bg-emerald-950/80 border border-emerald-500/40 px-1.5 sm:px-2 py-0.5 rounded leading-none">
                <ShieldCheck className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-emerald-400 shrink-0" />
                <span className="truncate max-w-[140px] sm:max-w-none">{slide.badge}</span>
              </span>

              <span className="text-[9px] sm:text-[11px] font-mono font-bold text-amber-300 bg-amber-950/70 border border-amber-500/40 px-1.5 sm:px-2 py-0.5 rounded leading-none">
                {slide.discountBadge}
              </span>
            </div>

            {/* Title */}
            <h2 className="text-xs sm:text-base md:text-xl font-extrabold text-white font-display uppercase tracking-tight leading-tight line-clamp-2">
              {slide.title}
            </h2>

            {/* Short detail */}
            <p className="text-[10px] sm:text-xs text-neutral-400 line-clamp-1 sm:line-clamp-2 leading-tight hidden xs:block">
              {slide.subtitle}
            </p>

            {/* Price tag */}
            <div className="flex items-baseline gap-1.5 sm:gap-2.5 pt-0.5">
              <span className="text-sm sm:text-lg md:text-2xl font-black text-emerald-400 font-mono-numbers">
                ৳{slide.price.toLocaleString()}
              </span>
              <span className="text-[10px] sm:text-xs text-neutral-500 line-through font-mono-numbers">
                ৳{slide.originalPrice.toLocaleString()}
              </span>
            </div>

            {/* Action Buttons ("এখনই কিনুন", "বিস্তারিত") */}
            <div className="flex items-center gap-1.5 sm:gap-2 pt-1">
              <button
                type="button"
                onClick={handleBuyNow}
                className="px-2 sm:px-3.5 py-1 sm:py-1.5 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-neutral-950 font-bold text-[10px] sm:text-xs rounded-lg transition-all shadow-[0_0_12px_rgba(16,185,129,0.3)] font-display uppercase tracking-wider whitespace-nowrap cursor-pointer"
              >
                এখনই কিনুন
              </button>

              <button
                type="button"
                onClick={handleViewDetails}
                className="px-1.5 sm:px-3 py-1 sm:py-1.5 bg-neutral-900/90 hover:bg-neutral-800 text-neutral-200 hover:text-white border border-neutral-700/80 text-[10px] sm:text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                বিস্তারিত
              </button>
            </div>
          </div>

          {/* Right Column (approx 50%): High-resolution product showcase photo framed cleanly with rounded corners */}
          <div className="w-1/2 p-2 sm:p-3 md:p-4 pr-7 sm:pr-10 flex items-center justify-center relative overflow-hidden bg-neutral-950">
            <div 
              onClick={handleViewDetails}
              className="relative w-full h-full max-h-[155px] sm:max-h-[200px] md:max-h-[230px] rounded-lg sm:rounded-xl overflow-hidden bg-neutral-900/90 border border-neutral-800 flex items-center justify-center p-2 cursor-pointer group shadow-inner"
            >
              <img
                src={getProductImageUrl(slide.image)}
                alt={slide.title}
                onError={(e) => {
                  (e.target as HTMLImageElement).src = heroBannerImg;
                }}
                referrerPolicy="no-referrer"
                className="max-h-full max-w-full object-contain object-center group-hover:scale-105 transition-transform duration-300 drop-shadow-[0_8px_16px_rgba(0,0,0,0.7)]"
              />

              {/* Subtle Tech Aura Glow */}
              <div className="absolute inset-0 bg-radial from-emerald-500/10 via-transparent to-transparent pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Slide Indicator Dots */}
        <div className="absolute left-8 sm:left-12 bottom-1 sm:bottom-1.5 z-20 flex items-center gap-1">
          {HERO_SLIDES.map((s, index) => (
            <button
              key={s.id}
              onClick={() => setCurrentSlide(index)}
              aria-label={`Go to slide ${index + 1}`}
              className={`h-1 rounded-full transition-all duration-300 cursor-pointer ${
                currentSlide === index 
                  ? 'w-5 bg-emerald-400 shadow-[0_0_6px_rgba(16,185,129,0.8)]' 
                  : 'w-1.5 bg-neutral-600 hover:bg-neutral-400'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
