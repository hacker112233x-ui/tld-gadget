import React from 'react';
import { useShop } from '../context/ShopContext';
import { PRODUCTS, getProductImageUrl, coolerImg } from '../data/products';
import { X, Heart, ShoppingCart, Trash2 } from 'lucide-react';

export const WishlistDrawer: React.FC = () => {
  const { 
    isWishlistOpen, 
    setIsWishlistOpen, 
    wishlist, 
    toggleWishlist, 
    addToCart,
    setSelectedProduct
  } = useShop();

  if (!isWishlistOpen) return null;

  const wishlistedProducts = PRODUCTS.filter(p => wishlist.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div 
        onClick={() => setIsWishlistOpen(false)}
        className="absolute inset-0 bg-neutral-950/75 backdrop-blur-sm transition-opacity" 
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-0 sm:pl-8">
        <div className="w-full max-w-md sm:w-md bg-neutral-900 border-l border-neutral-800 shadow-2xl flex flex-col justify-between">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/30">
                <Heart className="w-5 h-5 fill-rose-500 text-rose-500" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white font-display uppercase tracking-wider">
                  Saved Wishlist
                </h2>
                <span className="text-xs font-mono text-neutral-400">
                  {wishlistedProducts.length} item{wishlistedProducts.length !== 1 ? 's' : ''}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsWishlistOpen(false)}
              className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {wishlistedProducts.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-neutral-800/80 border border-neutral-700 flex items-center justify-center text-neutral-500">
                  <Heart className="w-8 h-8 text-neutral-500" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-semibold text-white">Your wishlist is empty</h3>
                  <p className="text-xs text-neutral-400 max-w-xs">
                    Tap the heart icon on any gear card to save it for quick access later.
                  </p>
                </div>
              </div>
            ) : (
              wishlistedProducts.map((product) => (
                <div
                  key={product.id}
                  className="flex gap-3 p-3 bg-neutral-950/70 rounded-xl border border-neutral-800 hover:border-neutral-700 transition-colors"
                >
                  <img
                    src={getProductImageUrl(product.image)}
                    alt={product.name}
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = coolerImg;
                    }}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 object-cover rounded-lg bg-neutral-900 border border-neutral-800 shrink-0 cursor-pointer"
                    onClick={() => {
                      setSelectedProduct(product);
                      setIsWishlistOpen(false);
                    }}
                  />

                  <div className="flex-1 flex flex-col justify-between min-w-0">
                    <div>
                      <div className="flex items-start justify-between gap-1">
                        <h4 
                          onClick={() => {
                            setSelectedProduct(product);
                            setIsWishlistOpen(false);
                          }}
                          className="text-xs sm:text-sm font-semibold text-neutral-100 hover:text-emerald-400 cursor-pointer truncate"
                        >
                          {product.name}
                        </h4>
                        <button
                          type="button"
                          onClick={() => toggleWishlist(product.id)}
                          className="p-1 text-neutral-500 hover:text-rose-400 transition-colors shrink-0"
                          title="Remove from wishlist"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <span className="text-sm font-bold text-white font-mono-numbers block mt-1">
                        ৳{product.price.toLocaleString()}
                      </span>
                    </div>

                    <div className="mt-2">
                      <button
                        type="button"
                        onClick={() => {
                          addToCart(product, 1, false);
                        }}
                        className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-neutral-950 border border-emerald-500/30 text-xs font-semibold rounded-md transition-all"
                      >
                        <ShoppingCart className="w-3.5 h-3.5" />
                        <span>Move to Cart</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Close button */}
          <div className="p-4 bg-neutral-950 border-t border-neutral-800">
            <button
              type="button"
              onClick={() => setIsWishlistOpen(false)}
              className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs rounded-lg transition-colors"
            >
              Continue Browsing
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
