import React from 'react';
import { useShop, STORE_PHONE_DISPLAY, STORE_PHONE_NUMBER } from '../context/ShopContext';
import { ProductCategory } from '../types';
import { 
  X, 
  Search, 
  User, 
  UserPlus, 
  Home, 
  Grid, 
  Gamepad2, 
  Trophy, 
  ChevronRight, 
  Sparkles, 
  PhoneCall, 
  Flame, 
  ShieldCheck,
  Disc,
  Headphones,
  Fan,
  Layers,
  Zap,
  Radio,
  Cpu,
  BatteryCharging
} from 'lucide-react';

interface CategoryNavSubLink {
  title: string;
  category: ProductCategory;
  icon: React.ElementType;
  badge?: string;
}

const CATEGORY_SUB_LINKS: CategoryNavSubLink[] = [
  {
    title: 'Gaming Finger Sleeves',
    category: 'Gaming Finger Sleeves',
    icon: Disc,
    badge: '24-Needle'
  },
  {
    title: 'Esports Gaming Headphones',
    category: 'Esports Gaming Headphones',
    icon: Headphones,
    badge: '7.1 Surround'
  },
  {
    title: 'Gaming Cooler',
    category: 'Gaming Cooler',
    icon: Fan,
    badge: '15W Fast'
  },
  {
    title: 'COMBO',
    category: 'COMBO',
    icon: Layers,
    badge: 'Best Value'
  },
  {
    title: 'Charger Adapter And Cable',
    category: 'Charger Adapter And Cable',
    icon: Zap
  },
  {
    title: 'Gaming TWS',
    category: 'Gaming TWS',
    icon: Radio,
    badge: '35ms Lag'
  },
  {
    title: 'Cooler Clips and Heat Sink Magnetic Plate',
    category: 'Cooler Clips and Heat Sink Magnetic Plate',
    icon: Cpu
  },
  {
    title: 'Power Bank',
    category: 'Power Bank',
    icon: BatteryCharging
  }
];

export const MobileMenuDrawer: React.FC = () => {
  const {
    isMenuDrawerOpen,
    setIsMenuDrawerOpen,
    setAuthModalMode,
    searchQuery,
    setSearchQuery,
    setSelectedCategory,
    activeTab,
    setActiveTab,
    isDark
  } = useShop();

  if (!isMenuDrawerOpen) return null;

  const handleCategoryClick = (cat: ProductCategory) => {
    setActiveTab('store');
    setSelectedCategory(cat);
    setIsMenuDrawerOpen(false);
    const catalogEl = document.getElementById('catalog-section');
    if (catalogEl) {
      catalogEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleNavClick = (tab: 'store' | 'digital' | 'leaderboard', cat?: ProductCategory) => {
    setActiveTab(tab);
    if (cat) {
      setSelectedCategory(cat);
    } else {
      setSelectedCategory('All');
    }
    setIsMenuDrawerOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        onClick={() => setIsMenuDrawerOpen(false)}
        className="absolute inset-0 bg-neutral-950/80 backdrop-blur-sm transition-opacity" 
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-6 sm:pl-10">
        <div className="w-screen max-w-sm sm:max-w-md bg-neutral-900 border-l border-neutral-800 shadow-2xl flex flex-col justify-between overflow-hidden animate-in slide-in-from-right duration-300">
          {/* Top Bar with Brand & Close Button */}
          <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/90">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-neutral-900 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                <Zap className="w-4 h-4 fill-emerald-500 text-emerald-400" />
              </div>
              <div className="flex items-center gap-1 font-display font-bold uppercase tracking-wider text-base text-white">
                <span>TLD <span className="text-emerald-400">GADGET</span></span>
                <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-1 py-0.5 rounded">.BD</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsMenuDrawerOpen(false)}
              className="p-2 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded-lg transition-colors cursor-pointer"
              aria-label="Close menu drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Scrollable Drawer Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5">
            {/* Top Section: Account Access prompt with "লগইন" (Login) and "রেজিস্টার" (Register) buttons */}
            <div className="p-4 rounded-xl bg-neutral-950/80 border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase text-neutral-400 font-semibold flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-emerald-400" />
                  <span>অ্যাকাউন্ট অ্যাক্সেস</span>
                </span>
                <span className="text-[10px] font-mono bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20">
                  সদস্য সুবিধা
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsMenuDrawerOpen(false);
                    setAuthModalMode('login');
                  }}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-neutral-950 font-bold text-xs shadow-[0_0_12px_rgba(16,185,129,0.3)] transition-all font-display uppercase tracking-wider cursor-pointer"
                >
                  <User className="w-3.5 h-3.5 fill-neutral-950" />
                  <span>লগইন</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsMenuDrawerOpen(false);
                    setAuthModalMode('register');
                  }}
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg bg-neutral-800 hover:bg-neutral-700 active:scale-95 text-neutral-200 hover:text-white border border-neutral-700 text-xs font-semibold transition-all cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5 text-emerald-400" />
                  <span>রেজিস্টার</span>
                </button>
              </div>
            </div>

            {/* Integrated Search Bar ("পণ্য খুঁজুন...") */}
            <div>
              <div className="relative flex items-center bg-neutral-950 border border-neutral-800 focus-within:border-emerald-500 rounded-xl px-3 py-2">
                <Search className="w-4 h-4 text-neutral-400 shrink-0 mr-2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="পণ্য খুঁজুন (e.g. Memo CX07, Sleeves)..."
                  className="w-full bg-transparent text-xs text-white placeholder:text-neutral-500 focus:outline-none"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="text-neutral-400 hover:text-white p-0.5"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>

            {/* Primary Navigation Links: "হোম", "সব পণ্য", "ডিজিটাল পণ্য", "লিডারবোর্ড" */}
            <div className="space-y-1">
              <span className="text-[11px] font-mono uppercase text-neutral-400 font-bold px-1 mb-1 block">
                মূল মেনু (Navigation)
              </span>

              <button
                type="button"
                onClick={() => handleNavClick('store', 'All')}
                className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                  activeTab === 'store' && !searchQuery
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    : 'text-neutral-200 hover:bg-neutral-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Home className="w-4 h-4 text-emerald-400" />
                  <span>হোম (Home)</span>
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-500" />
              </button>

              <button
                type="button"
                onClick={() => handleCategoryClick('All')}
                className="w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-semibold text-neutral-200 hover:bg-neutral-800 hover:text-white transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <Grid className="w-4 h-4 text-emerald-400" />
                  <span>সব পণ্য (All Products)</span>
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-500" />
              </button>

              <button
                type="button"
                onClick={() => handleNavClick('digital')}
                className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                  activeTab === 'digital'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    : 'text-neutral-200 hover:bg-neutral-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Gamepad2 className="w-4 h-4 text-purple-400" />
                  <span>ডিজিটাল পণ্য (Digital Products / UC & Topup)</span>
                </div>
                <span className="text-[10px] font-mono bg-purple-500/20 text-purple-300 px-1.5 py-0.2 rounded border border-purple-500/30">
                  NEW
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleNavClick('leaderboard')}
                className={`w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                  activeTab === 'leaderboard'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    : 'text-neutral-200 hover:bg-neutral-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Trophy className="w-4 h-4 text-amber-400" />
                  <span>লিডারবোর্ড (Gamer Leaderboard)</span>
                </div>
                <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded border border-amber-500/30">
                  RANK
                </span>
              </button>
            </div>

            {/* Categorized Product Sub-links with icons/arrows */}
            <div className="space-y-1 pt-2 border-t border-neutral-800">
              <span className="text-[11px] font-mono uppercase text-neutral-400 font-bold px-1 mb-1 block">
                ক্যাটাগরি সমূহ (Product Categories)
              </span>

              <div className="space-y-1">
                {CATEGORY_SUB_LINKS.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.title}
                      type="button"
                      onClick={() => handleCategoryClick(item.category)}
                      className="w-full flex items-center justify-between p-2.5 rounded-xl text-xs text-neutral-300 hover:text-white hover:bg-neutral-800/80 transition-colors group cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <div className="p-1.5 rounded-lg bg-neutral-950 border border-neutral-800 text-emerald-400 group-hover:border-emerald-500/40">
                          <Icon className="w-3.5 h-3.5" />
                        </div>
                        <span className="truncate font-medium">{item.title}</span>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {item.badge && (
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400 group-hover:text-emerald-400 border border-neutral-700">
                            {item.badge}
                          </span>
                        )}
                        <ChevronRight className="w-4 h-4 text-neutral-600 group-hover:text-emerald-400 group-hover:translate-x-0.5 transition-transform" />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Drawer Footer Hotline */}
          <div className="p-4 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-neutral-300">
              <PhoneCall className="w-4 h-4 text-emerald-400" />
              <div>
                <span className="text-[10px] text-neutral-500 block leading-tight">সাপোর্ট হটলাইন</span>
                <a href={`tel:${STORE_PHONE_NUMBER}`} className="font-mono text-emerald-400 font-bold hover:underline">
                  {STORE_PHONE_DISPLAY}
                </a>
              </div>
            </div>
            <a
              href={`https://wa.me/${STORE_PHONE_NUMBER.replace('+', '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500 hover:text-neutral-950 text-emerald-400 border border-emerald-500/30 text-xs font-semibold transition-all font-mono"
            >
              WhatsApp
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
