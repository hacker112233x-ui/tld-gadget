import React from 'react';
import { useShop } from '../context/ShopContext';
import { Trophy, Medal, Flame, Star, Award, ArrowLeft } from 'lucide-react';

export const LeaderboardView: React.FC = () => {
  const { setActiveTab } = useShop();

  const TOP_GAMERS = [
    { rank: 1, name: 'Sabbir "ApexPredator"', city: 'Dhaka', points: '14,250 PTS', badge: 'LEGENDARY', orders: 18 },
    { rank: 2, name: 'Rakib "SilentHeadshot"', city: 'Chittagong', points: '11,800 PTS', badge: 'CONQUEROR', orders: 14 },
    { rank: 3, name: 'Tanvir "CyberWolf"', city: 'Sylhet', points: '9,450 PTS', badge: 'ACE MASTER', orders: 11 },
    { rank: 4, name: 'Shahadat "ClawGod"', city: 'Rajshahi', points: '7,920 PTS', badge: 'DIAMOND I', orders: 9 },
    { rank: 5, name: 'Mehedi "ShadowStrike"', city: 'Khulna', points: '6,400 PTS', badge: 'DIAMOND II', orders: 7 },
    { rank: 6, name: 'Arif "QuickScope"', city: 'Dhaka', points: '5,150 PTS', badge: 'PLATINUM', orders: 6 }
  ];

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 w-full box-border">
      {/* Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-amber-950/70 via-neutral-900 to-neutral-900 border border-amber-500/30 mb-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Trophy className="w-5 h-5" />
              </span>
              <span className="text-xs font-mono font-bold uppercase text-amber-400 tracking-wider">
                TLD GAMERS LEADERBOARD
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display uppercase tracking-tight">
              মাসিক শীর্ষ গেমার লিডারবোর্ড ও রিওয়ার্ড
            </h2>
            <p className="text-xs sm:text-sm text-neutral-300 mt-1 max-w-xl">
              প্রতিটি অর্ডারে পয়েন্ট অর্জন করুন এবং প্রতি মাসের শেষে জিতে নিন বিশেষ মেমো কুলার এবং ডিসকাউন্ট কুপন!
            </p>
          </div>

          <button
            type="button"
            onClick={() => setActiveTab('store')}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-xl border border-neutral-700 transition-colors flex items-center gap-1.5"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>গ্যাজেট স্টোরে ফিরে যান</span>
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-neutral-900 rounded-2xl border border-neutral-800 overflow-hidden shadow-xl">
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <span className="font-bold text-white uppercase text-sm font-display">এই মাসের শীর্ষ গেমার্স</span>
          </div>
          <span className="text-xs font-mono text-emerald-400">আপডেট: আজকের লাইভ র‍্যাংকিং</span>
        </div>

        <div className="divide-y divide-neutral-800 text-xs sm:text-sm">
          {TOP_GAMERS.map((g) => (
            <div key={g.rank} className="p-4 flex items-center justify-between hover:bg-neutral-800/40 transition-colors">
              <div className="flex items-center gap-3.5">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold font-mono text-xs ${
                  g.rank === 1 ? 'bg-amber-400 text-black shadow-[0_0_10px_rgba(251,191,36,0.6)]' :
                  g.rank === 2 ? 'bg-neutral-300 text-black' :
                  g.rank === 3 ? 'bg-amber-700 text-white' : 'bg-neutral-800 text-neutral-400'
                }`}>
                  #{g.rank}
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm leading-tight flex items-center gap-2">
                    <span>{g.name}</span>
                    <span className="text-[10px] font-mono font-normal px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400">
                      {g.city}
                    </span>
                  </h4>
                  <span className="text-neutral-500 text-xs">অর্ডার সংখ্যা: {g.orders}টি</span>
                </div>
              </div>

              <div className="text-right">
                <span className="font-mono font-bold text-emerald-400 block sm:text-base">{g.points}</span>
                <span className="text-[10px] font-mono text-amber-300 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-500/30">
                  {g.badge}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
