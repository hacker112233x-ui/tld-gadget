import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { X, User, Lock, Phone, ArrowRight, ShieldCheck, CheckCircle2, Sparkles } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { authModalMode, setAuthModalMode, showToast } = useShop();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!authModalMode) return null;

  const isLogin = authModalMode === 'login';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim() || !password.trim()) {
      showToast('অনুগ্রহ করে সব তথ্য পূরণ করুন');
      return;
    }

    setIsSuccess(true);
    showToast(isLogin ? 'সাফল্যের সাথে লগইন হয়েছে!' : 'রেজিস্ট্রেশন সফল হয়েছে!');
    setTimeout(() => {
      setIsSuccess(false);
      setAuthModalMode(null);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div 
        className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/80">
          <div>
            <span className="text-[11px] font-mono text-emerald-400 uppercase font-semibold">
              TLD GADGET.BD Gamer Club
            </span>
            <h3 className="text-lg font-bold text-white font-display uppercase tracking-wider">
              {isLogin ? 'অ্যাকাউন্টে লগইন করুন' : 'নতুন অ্যাকাউন্ট তৈরি করুন'}
            </h3>
          </div>

          <button
            type="button"
            onClick={() => setAuthModalMode(null)}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          {!isLogin && (
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                আপনার পুরো নাম (Full Name)
              </label>
              <div className="relative flex items-center">
                <User className="w-4 h-4 text-neutral-500 absolute left-3" />
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. তানভীর আহমেদ"
                  className="w-full bg-neutral-950 border border-neutral-800 text-sm text-white rounded-xl py-2.5 pl-9 pr-3 focus:outline-none focus:border-emerald-500"
                  required={!isLogin}
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">
              মোবাইল নম্বর অথবা ইমেইল (Mobile / Email)
            </label>
            <div className="relative flex items-center">
              <Phone className="w-4 h-4 text-neutral-500 absolute left-3" />
              <input
                type="text"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="017XXXXXXXX বা gamer@gmail.com"
                className="w-full bg-neutral-950 border border-neutral-800 text-sm text-white rounded-xl py-2.5 pl-9 pr-3 font-mono focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-medium text-neutral-300">
                পাসওয়ার্ড (Password)
              </label>
              {isLogin && (
                <button
                  type="button"
                  onClick={() => showToast('পাসওয়ার্ড রিসেট লিংক আপনার নম্বরে পাঠানো হয়েছে')}
                  className="text-[11px] text-emerald-400 hover:underline"
                >
                  ভুলে গেছেন?
                </button>
              )}
            </div>
            <div className="relative flex items-center">
              <Lock className="w-4 h-4 text-neutral-500 absolute left-3" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-neutral-950 border border-neutral-800 text-sm text-white rounded-xl py-2.5 pl-9 pr-3 font-mono focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-500 hover:bg-emerald-400 active:scale-98 text-neutral-950 font-bold text-sm rounded-xl shadow-[0_0_15px_rgba(16,185,129,0.3)] transition-all font-display uppercase tracking-wider cursor-pointer"
          >
            {isSuccess ? (
              <span className="flex items-center gap-1.5 text-neutral-950 font-bold">
                <CheckCircle2 className="w-4 h-4" /> সম্পন্ন হয়েছে
              </span>
            ) : (
              <span>{isLogin ? 'লগইন করুন' : 'রেজিস্ট্রেশন করুন'}</span>
            )}
            <ArrowRight className="w-4 h-4" />
          </button>

          {/* Toggle between Login and Register */}
          <div className="text-center text-xs text-neutral-400 pt-2 border-t border-neutral-800">
            {isLogin ? (
              <span>
                অ্যাকাউন্ট নেই?{' '}
                <button
                  type="button"
                  onClick={() => setAuthModalMode('register')}
                  className="text-emerald-400 font-bold hover:underline ml-1"
                >
                  নতুন অ্যাকাউন্ট রেজিস্টার করুন
                </button>
              </span>
            ) : (
              <span>
                ইতিমধ্যে অ্যাকাউন্ট আছে?{' '}
                <button
                  type="button"
                  onClick={() => setAuthModalMode('login')}
                  className="text-emerald-400 font-bold hover:underline ml-1"
                >
                  সরাসরি লগইন করুন
                </button>
              </span>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
