import React from 'react';
import { useShop, STORE_PHONE_DISPLAY, STORE_PHONE_NUMBER } from '../context/ShopContext';
import { 
  Zap, 
  MapPin, 
  PhoneCall, 
  Mail, 
  Facebook, 
  MessageCircle, 
  ShieldCheck, 
  Heart,
  ChevronRight
} from 'lucide-react';
import { ProductCategory } from '../types';

export const Footer: React.FC = () => {
  const { setActivePolicy, setSelectedCategory } = useShop();

  const handleCategoryNav = (cat: ProductCategory) => {
    setSelectedCategory(cat);
    const catalogEl = document.getElementById('catalog-section');
    if (catalogEl) {
      catalogEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const cleanPhone = STORE_PHONE_NUMBER.replace('+', '');

  return (
    <footer className="bg-neutral-950 border-t border-neutral-800/90 text-neutral-400 text-xs mt-16 w-full box-border overflow-hidden">
      {/* Top Banner inside Footer */}
      <div className="border-b border-neutral-850 py-6 sm:py-8 px-3 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full box-border">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-neutral-900 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Zap className="w-6 h-6 fill-emerald-500 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-bold tracking-wider text-white font-display uppercase">
                  TLD <span className="text-emerald-400">GADGET</span>
                </span>
                <span className="text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-1 py-0.5 rounded">
                  .BD
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                বেস্ট গেমিং ও মোবাইল স্পোর্টস গিয়ার হাব বাংলাদেশ
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800 transition-colors"
            >
              <Facebook className="w-4 h-4 text-blue-400" />
              <span>Facebook Official Page</span>
            </a>
            <a
              href={`https://wa.me/${cleanPhone}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-neutral-950 border border-emerald-500/30 transition-colors font-semibold"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp চ্যাট: {STORE_PHONE_DISPLAY}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Columns Grid */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-10 sm:py-12 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 w-full box-border">
        {/* Col 1: Store Info & Updated Helpline */}
        <div className="space-y-3">
          <h4 className="text-white text-xs font-mono uppercase tracking-widest font-bold">
            স্টোর ঠিকানা ও হেল্পলাইন
          </h4>
          <div className="space-y-2.5 text-neutral-400">
            <div className="flex items-start gap-2.5">
              <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>লেভেল ৪, মাল্টিপ্ল্যান কম্পিউটার সেন্টার, নিউ এলিফ্যান্ট রোড, ঢাকা-১২০৫, বাংলাদেশ</span>
            </div>
            <div className="flex items-center gap-2.5">
              <PhoneCall className="w-4 h-4 text-emerald-400 shrink-0" />
              <a href={`tel:${STORE_PHONE_NUMBER}`} className="font-mono text-emerald-400 font-bold hover:underline">
                {STORE_PHONE_DISPLAY} (সকাল ১০টা - রাত ১০টা)
              </a>
            </div>
            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>support@tldgadget.bd</span>
            </div>
          </div>
        </div>

        {/* Col 2: Popular Categories */}
        <div className="space-y-3">
          <h4 className="text-white text-xs font-mono uppercase tracking-widest font-bold">
            গেমিং ক্যাটাগরি
          </h4>
          <ul className="space-y-2">
            {[
              { label: 'Gaming Finger Sleeves', cat: 'Gaming Finger Sleeves' as ProductCategory },
              { label: 'Gaming Cooler (Memo CX07 & DL05)', cat: 'Gaming Cooler' as ProductCategory },
              { label: 'Esports Gaming Headphones', cat: 'Esports Gaming Headphones' as ProductCategory },
              { label: 'Gaming TWS Earbuds', cat: 'Gaming TWS' as ProductCategory },
              { label: 'COMBO Packs (All-in-One)', cat: 'COMBO' as ProductCategory },
              { label: 'Charger Adapter And Cable', cat: 'Charger Adapter And Cable' as ProductCategory },
            ].map((item) => (
              <li key={item.label}>
                <button
                  type="button"
                  onClick={() => handleCategoryNav(item.cat)}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1.5 text-left cursor-pointer"
                >
                  <ChevronRight className="w-3 h-3 text-emerald-500/60 shrink-0" />
                  <span>{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Col 3: Customer Policies */}
        <div className="space-y-3">
          <h4 className="text-white text-xs font-mono uppercase tracking-widest font-bold">
            গ্রাহক সুবিধা ও পলিসি
          </h4>
          <ul className="space-y-2">
            <li>
              <button
                type="button"
                onClick={() => setActivePolicy('return')}
                className="hover:text-emerald-400 transition-colors text-left flex items-center gap-1.5 cursor-pointer"
              >
                <ChevronRight className="w-3 h-3 text-emerald-500/60" />
                <span>৭ দিনের ইনস্ট্যান্ট রিপ্লেসমেন্ট গ্যারান্টি</span>
              </button>
            </li>
            <li>
              <button
                type="button"
                onClick={() => setActivePolicy('shipping')}
                className="hover:text-emerald-400 transition-colors text-left flex items-center gap-1.5 cursor-pointer"
              >
                <ChevronRight className="w-3 h-3 text-emerald-500/60" />
                <span>৬৪ জেলায় ক্যাশ অন ডেলিভারি</span>
              </button>
            </li>
            <li>
              <button
                type="button"
                onClick={() => setActivePolicy('privacy')}
                className="hover:text-emerald-400 transition-colors text-left flex items-center gap-1.5 cursor-pointer"
              >
                <ChevronRight className="w-3 h-3 text-emerald-500/60" />
                <span>গোপনীয়তা ও নিরাপত্তা পলিসি</span>
              </button>
            </li>
            <li>
              <button
                type="button"
                onClick={() => setActivePolicy('terms')}
                className="hover:text-emerald-400 transition-colors text-left flex items-center gap-1.5 cursor-pointer"
              >
                <ChevronRight className="w-3 h-3 text-emerald-500/60" />
                <span>শর্তাবলী ও নিয়মাবলী</span>
              </button>
            </li>
          </ul>
        </div>

        {/* Col 4: Payment Methods */}
        <div className="space-y-3">
          <h4 className="text-white text-xs font-mono uppercase tracking-widest font-bold">
            নিরাপদ পেমেন্ট মেথড
          </h4>
          <p className="text-xs text-neutral-400 leading-relaxed">
            পার্সেল হাতে পেয়ে চেক করে টাকা দিন (Cash on Delivery), অথবা বিকাশ ও নগদে সরাসরি সেন্ড মানি করুন।
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            <span className="px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800 text-[11px] font-mono font-semibold text-emerald-400">
              Cash on Delivery (ক্যাশ অন ডেলিভারি)
            </span>
            <span className="px-2.5 py-1 rounded bg-pink-950/40 border border-pink-500/30 text-[11px] font-mono font-semibold text-pink-400">
              bKash (বিকাশ)
            </span>
            <span className="px-2.5 py-1 rounded bg-orange-950/40 border border-orange-500/30 text-[11px] font-mono font-semibold text-orange-400">
              Nagad (নগদ)
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Quiet Copyright Bar */}
      <div className="border-t border-neutral-900 py-6 px-3 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-neutral-500 w-full box-border">
        <div>
          © {new Date().getFullYear()} TLD GADGET.BD. সর্বস্বত্ব সংরক্ষিত | ঢাকা, বাংলাদেশ।
        </div>
        <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-mono">
          <span>হটলাইন: {STORE_PHONE_DISPLAY}</span>
        </div>
      </div>
    </footer>
  );
};
