import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { 
  Search, 
  ShoppingCart, 
  Heart, 
  Sun, 
  Moon, 
  Zap, 
  X,
  Menu
} from 'lucide-react';

export const Header: React.FC = () => {
  const { 
    isDark, 
    toggleTheme, 
    searchQuery, 
    setSearchQuery, 
    cartCount, 
    setIsCartOpen,
    wishlist,
    setIsWishlistOpen,
    setIsMenuDrawerOpen
  } = useShop();

  const [isSearchFocused, setIsSearchFocused] = useState(false);

  return (
    <header className={`sticky top-0 z-40 w-full max-w-[100vw] backdrop-blur-md transition-colors duration-200 border-b box-border overflow-hidden ${
      isDark 
        ? 'bg-neutral-950/95 border-neutral-800/80 text-white' 
        : 'bg-white/95 border-neutral-200 text-neutral-900 shadow-sm'
    }`}>
      {/* Micro Announcement Bar */}
      <div className="bg-emerald-950/85 border-b border-emerald-500/20 text-emerald-400 text-xs py-1.5 px-3 sm:px-4 w-full box-border">
        <div className="max-w-7xl mx-auto flex items-center justify-center text-center">
          <div className="flex items-center justify-center gap-1.5 sm:gap-2 text-[10px] xs:text-[11px] sm:text-xs font-semibold text-emerald-400 leading-tight">
            <span>🚚 সারা বাংলাদেশে ক্যাশ অন ডেলিভারি</span>
            <span className="text-emerald-600">|</span>
            <span>⚡ দ্রুততম ডেলিভারি</span>
            <span className="text-emerald-600">|</span>
            <span>💯 শতভাগ জেনুইন প্রোডাক্ট</span>
          </div>
        </div>
      </div>

      {/* Main Header Container with exact flex justify-between alignment */}
      <div 
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '10px 16px',
          width: '100%',
          boxSizing: 'border-box'
        }}
        className="max-w-7xl mx-auto"
      >
        {/* Left: Official Store Logo & Brand Name */}
        <div className="flex items-center gap-2 shrink-0">
          <a 
            href="#" 
            className="group flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-lg"
          >
            {/* Store Logo (max-height: 36px) */}
            <div className="h-9 w-9 max-h-[36px] max-w-[36px] rounded-lg bg-neutral-900 border border-emerald-500/50 flex items-center justify-center text-emerald-400 group-hover:border-emerald-400 group-hover:shadow-[0_0_12px_rgba(16,185,129,0.4)] transition-all shrink-0">
              <Zap className="w-5 h-5 fill-emerald-500 text-emerald-400" />
            </div>

            {/* Brand Title */}
            <div className="flex items-center gap-1 leading-none">
              <span className={`text-base sm:text-lg md:text-xl font-bold tracking-wider font-display uppercase ${
                isDark ? 'text-white' : 'text-neutral-900'
              }`}>
                TLD <span className="text-emerald-400">GADGET</span>
              </span>
              <span className="text-[9px] sm:text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-1 py-0.5 rounded leading-none">
                .BD
              </span>
            </div>
          </a>
        </div>

        {/* Center: Live Search Bar (Desktop / Tablet view) */}
        <div className="hidden md:flex flex-1 max-w-sm mx-4 relative">
          <div className={`relative w-full flex items-center rounded-xl transition-all duration-200 ${
            isSearchFocused 
              ? 'ring-2 ring-emerald-500/80 border-emerald-500/40' 
              : isDark ? 'bg-neutral-900/90 border border-neutral-800' : 'bg-neutral-100 border border-neutral-300'
          }`}>
            <Search className="w-4 h-4 ml-3 text-neutral-400 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setIsSearchFocused(false)}
              placeholder="পণ্য খুঁজুন (e.g. Memo CX07)..."
              className={`w-full py-1.5 pl-2 pr-8 bg-transparent text-xs placeholder:text-neutral-500 focus:outline-none ${
                isDark ? 'text-neutral-100' : 'text-neutral-900'
              }`}
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2 p-0.5 text-neutral-400 hover:text-white"
                title="মুছে ফেলুন"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Right: Theme Toggle, Cart Icon (🛒), and Hamburger Menu (☰) */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Dark / Light Mode Toggle */}
          <button
            type="button"
            onClick={toggleTheme}
            className="p-2 text-neutral-400 hover:text-neutral-100 hover:bg-neutral-800/60 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 cursor-pointer"
            title={isDark ? 'লাইট মোড চালু করুন' : 'ডার্ক মোড চালু করুন'}
            aria-label="Toggle theme"
          >
            {isDark ? (
              <Sun className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 sm:w-5 sm:h-5 text-neutral-700" />
            )}
          </button>

          {/* Wishlist Button */}
          <button
            type="button"
            onClick={() => setIsWishlistOpen(true)}
            className="relative p-2 text-neutral-300 hover:text-emerald-400 hover:bg-neutral-800/60 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 cursor-pointer"
            title="উইশলিস্ট দেখুন"
            aria-label="View Wishlist"
          >
            <Heart className={`w-4 h-4 sm:w-5 sm:h-5 ${wishlist.length > 0 ? 'fill-rose-500 text-rose-500' : ''}`} />
            {wishlist.length > 0 && (
              <span className="absolute -top-0.5 -right-0.5 flex items-center justify-center min-w-[16px] h-[16px] text-[9px] font-bold text-white bg-rose-600 rounded-full px-1">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* Shopping Cart Button (🛒) with live counter badge */}
          <button
            type="button"
            onClick={() => setIsCartOpen(true)}
            className="relative flex items-center gap-1 sm:gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-2 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-neutral-950 font-bold rounded-xl transition-all shadow-[0_0_12px_rgba(16,185,129,0.3)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-300 cursor-pointer"
            title="শপিং কার্ট খুলুন"
            aria-label="Shopping Cart"
          >
            <ShoppingCart className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
            <span className="flex items-center justify-center min-w-[18px] h-[18px] text-[10px] sm:text-xs font-black text-white bg-neutral-950 rounded-full px-1">
              {cartCount}
            </span>
          </button>

          {/* Hamburger Menu icon (☰) on the far top right edge */}
          <button
            type="button"
            onClick={() => setIsMenuDrawerOpen(true)}
            className="p-1.5 sm:p-2 text-neutral-200 hover:text-emerald-400 bg-neutral-900/90 hover:bg-neutral-800 border border-neutral-700/80 rounded-xl transition-all cursor-pointer shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ml-0.5"
            title="মেনু খুলুন"
            aria-label="Open Navigation Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
