import React, { useState } from 'react';
import { useShop, STORE_PHONE_NUMBER, STORE_PHONE_DISPLAY } from '../context/ShopContext';
import { MessageCircle, X, Send, PhoneCall, Zap, HelpCircle } from 'lucide-react';

export const WhatsAppFloatingButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [customMsg, setCustomMsg] = useState('');

  const phoneNum = STORE_PHONE_NUMBER.replace('+', ''); // '8801742428157'

  const quickPrompts = [
    'আসসালামু আলাইকুম! আমি Memo CX07 কুলার ও গেমিং স্লিভস অর্ডার করতে চাই।',
    'আমার এলাকায় ক্যাশ অন ডেলিভারি এবং ডেলিভারি চার্জ কত?',
    'PUBG / FreeFire-এর জন্য সেরা লো-লেটেন্সি TWS বা হেডফোন কোনটি?'
  ];

  const handleSendPrompt = (text: string) => {
    const url = `https://wa.me/${phoneNum}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
    setIsOpen(false);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customMsg.trim()) return;
    handleSendPrompt(customMsg);
    setCustomMsg('');
  };

  const handleDirectCall = () => {
    window.location.href = `tel:${STORE_PHONE_NUMBER}`;
  };

  return (
    <div className="fixed bottom-5 right-4 sm:right-6 z-40">
      {/* Help Popup Window */}
      {isOpen && (
        <div className="absolute bottom-16 right-0 w-[calc(100vw-2rem)] sm:w-88 max-w-sm bg-neutral-900 border border-emerald-500/50 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="p-4 bg-emerald-950/90 border-b border-emerald-500/20 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-emerald-500 flex items-center justify-center text-neutral-950 font-bold shadow-[0_0_10px_rgba(16,185,129,0.5)] shrink-0">
                <MessageCircle className="w-5 h-5 fill-neutral-950" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white font-display uppercase tracking-wider">
                  TLD কাস্টমার কেয়ার
                </h4>
                <span className="text-[11px] text-emerald-400 font-mono flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  হটলাইন: {STORE_PHONE_DISPLAY}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="p-1 text-neutral-400 hover:text-white rounded-lg transition-colors cursor-pointer"
              aria-label="Close help popup"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Body */}
          <div className="p-4 space-y-3 bg-neutral-900">
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleSendPrompt('আসসালামু আলাইকুম! আমি TLD GADGET থেকে পণ্য অর্ডার করতে চাই।')}
                className="flex items-center justify-center gap-1.5 py-2.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs shadow-md transition-all cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp চ্যাট</span>
              </button>

              <button
                type="button"
                onClick={handleDirectCall}
                className="flex items-center justify-center gap-1.5 py-2.5 px-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 rounded-xl font-bold text-xs border border-neutral-700 transition-all cursor-pointer"
              >
                <PhoneCall className="w-4 h-4 text-emerald-400" />
                <span>সরাসরি কল</span>
              </button>
            </div>

            <p className="text-[11px] text-neutral-300 font-medium">
              দ্রুত উত্তরের জন্য নিচের যেকোনো প্রশ্নে ট্যাপ করুন:
            </p>

            <div className="space-y-1.5">
              {quickPrompts.map((prompt, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSendPrompt(prompt)}
                  className="w-full text-left p-2.5 rounded-lg bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-xs text-neutral-200 transition-colors flex items-center justify-between group cursor-pointer"
                >
                  <span className="line-clamp-1">{prompt}</span>
                  <Zap className="w-3.5 h-3.5 text-emerald-400 opacity-70 group-hover:opacity-100 shrink-0 ml-1" />
                </button>
              ))}
            </div>

            {/* Custom Input */}
            <form onSubmit={handleCustomSubmit} className="pt-1 flex gap-1.5">
              <input
                type="text"
                value={customMsg}
                onChange={(e) => setCustomMsg(e.target.value)}
                placeholder="আপনার বার্তা লিখুন..."
                className="flex-1 bg-neutral-950 border border-neutral-800 text-xs text-white rounded-lg px-2.5 py-2 focus:outline-none focus:border-emerald-500"
              />
              <button
                type="submit"
                className="p-2 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 rounded-lg transition-colors shrink-0 cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

            <div className="text-center pt-1">
              <a
                href={`tel:${STORE_PHONE_NUMBER}`}
                className="inline-flex items-center gap-1.5 text-[11px] font-mono text-neutral-400 hover:text-emerald-400 transition-colors"
              >
                <PhoneCall className="w-3 h-3 text-emerald-400" />
                <span>হটলাইন নম্বর: {STORE_PHONE_DISPLAY}</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Floating Action Trigger Button: "সাহায্য দরকার?" */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="relative group flex items-center gap-2 px-3.5 sm:px-4 py-3 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-neutral-950 font-bold rounded-full shadow-[0_4px_25px_rgba(16,185,129,0.5)] transition-all cursor-pointer border-2 border-emerald-300/40"
        aria-label="সাহায্য দরকার? - কাস্টমার সাপোর্ট ও হেল্পলাইন"
      >
        <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 fill-neutral-950" />
        <span className="text-xs sm:text-sm font-display uppercase tracking-wide font-extrabold whitespace-nowrap">
          সাহায্য দরকার?
        </span>
        <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-300 border-2 border-neutral-950 animate-ping" />
      </button>
    </div>
  );
};
