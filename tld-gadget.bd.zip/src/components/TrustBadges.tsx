import React from 'react';
import { ShieldCheck, Banknote, Truck, RotateCcw } from 'lucide-react';

export const TrustBadges: React.FC = () => {
  const BADGES = [
    {
      icon: ShieldCheck,
      title: '100% Original Products',
      desc: 'Authentic esports mobile hardware with verified quality check.'
    },
    {
      icon: Banknote,
      title: 'Cash on Delivery Available',
      desc: 'Inspect package upon arrival across all 64 districts in Bangladesh.'
    },
    {
      icon: Truck,
      title: 'Fast Shipping in Bangladesh',
      desc: '24-48 Hours delivery in Dhaka city & 48-72 Hours nationwide.'
    },
    {
      icon: RotateCcw,
      title: '7 Days Replacement Warranty',
      desc: 'Immediate replacement in case of any manufacturing defects.'
    }
  ];

  return (
    <section className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 sm:py-10 w-full box-border overflow-hidden">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {BADGES.map((b, idx) => {
          const Icon = b.icon;
          return (
            <div
              key={idx}
              className="p-5 rounded-xl bg-neutral-900 border border-neutral-800/90 hover:border-emerald-500/40 transition-colors flex items-start gap-4"
            >
              <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0">
                <Icon className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-white font-display tracking-tight">
                  {b.title}
                </h4>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  {b.desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
