import React from 'react';
import { useShop, STORE_PHONE_NUMBER } from '../context/ShopContext';
import { Gamepad2, Zap, ShieldCheck, ArrowRight, Star, MessageCircle } from 'lucide-react';

export const DigitalGoodsView: React.FC = () => {
  const { showToast, setActiveTab } = useShop();

  const DIGITAL_PRODUCTS = [
    {
      id: 'pubg-uc-pack',
      title: 'PUBG Mobile 325 UC + 60 Bonus Pack',
      game: 'PUBG Mobile',
      price: 490,
      originalPrice: 550,
      delivery: 'Instant In-Game Delivery (Player ID)',
      badge: 'POPULAR'
    },
    {
      id: 'freefire-diamonds',
      title: 'Free Fire 610 Diamonds Top-Up',
      game: 'Garena Free Fire MAX',
      price: 460,
      originalPrice: 520,
      delivery: 'Direct Player ID Recharge (2-5 mins)',
      badge: 'INSTANT'
    },
    {
      id: 'discord-nitro',
      title: 'Discord Nitro 1 Month Global Subscription Code',
      game: 'Discord Esports Community',
      price: 1150,
      originalPrice: 1350,
      delivery: 'Activation Redeem Link via SMS / WhatsApp',
      badge: 'OFFICIAL'
    },
    {
      id: 'google-play-card',
      title: 'Google Play $5 / $10 US Gift Card Code',
      game: 'Google Play Store',
      price: 650,
      originalPrice: 720,
      delivery: 'Digital Code Delivery',
      badge: 'VERIFIED'
    }
  ];

  const handleOrderDigital = (title: string, price: number) => {
    const text = encodeURIComponent(`Hi TLD GADGET.BD! I want to purchase Digital Item: ${title} for ৳${price}. Please send payment steps.`);
    window.open(`https://wa.me/${STORE_PHONE_NUMBER.replace('+', '')}?text=${text}`, '_blank');
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 w-full box-border">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-purple-950/70 via-neutral-900 to-neutral-900 border border-purple-500/30 mb-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-purple-500/20 text-purple-400 border border-purple-500/30">
                <Gamepad2 className="w-5 h-5" />
              </span>
              <span className="text-xs font-mono font-bold uppercase text-purple-400 tracking-wider">
                TLD DIGITAL ARSENAL
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display uppercase tracking-tight">
              ইন-গেম টপ-আপ এবং ডিজিটাল গিফট কার্ড
            </h2>
            <p className="text-xs sm:text-sm text-neutral-300 mt-1 max-w-xl">
              PUBG Mobile UC, Free Fire Diamonds এবং Discord Nitro তাৎক্ষণিক রিচার্জ করুন বিশ্বস্ততার সাথে।
            </p>
          </div>

          <button
            type="button"
            onClick={() => setActiveTab('store')}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-xl border border-neutral-700 transition-colors"
          >
            ← ফিজিক্যাল গ্যাজেট স্টোরে ফিরে যান
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {DIGITAL_PRODUCTS.map((prod) => (
          <div
            key={prod.id}
            className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-purple-500/50 flex flex-col justify-between transition-all"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-neutral-400 mb-2 font-mono">
                <span>{prod.game}</span>
                <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30">
                  {prod.badge}
                </span>
              </div>
              <h3 className="text-sm font-bold text-white mb-2 leading-snug">
                {prod.title}
              </h3>
              <p className="text-xs text-neutral-400 mb-4 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{prod.delivery}</span>
              </p>
            </div>

            <div className="pt-3 border-t border-neutral-800">
              <div className="flex items-baseline gap-2 mb-3">
                <span className="text-xl font-bold text-white font-mono-numbers">৳{prod.price}</span>
                <span className="text-xs text-neutral-500 line-through font-mono-numbers">৳{prod.originalPrice}</span>
              </div>

              <button
                type="button"
                onClick={() => handleOrderDigital(prod.title, prod.price)}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-purple-600 hover:bg-purple-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-lg transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>এখনই অর্ডার করুন (WhatsApp)</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
