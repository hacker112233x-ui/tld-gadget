import { Product } from '../types';

import heroBannerImg from '../assets/images/hero_gaming_gears_banner_1790270795601.jpg';
import sleevesImg from '../assets/images/product_finger_sleeves_pro_1790270810435.jpg';
import coolerImg from '../assets/images/product_magnetic_phone_cooler_1790270821837.jpg';
import twsImg from '../assets/images/product_tws_gaming_earbuds_1790270834744.jpg';
import comboImg from '../assets/images/product_combo_gaming_kit_1790270845306.jpg';

export { heroBannerImg, coolerImg, sleevesImg, twsImg, comboImg };

export const getProductImageUrl = (url: string): string => {
  if (!url) return coolerImg;
  if (url.includes('ibb.co.com/WNnM9kB1') || url.includes('ibb.co/WNnM9kB1')) {
    return 'https://i.ibb.co/20qC2vcB/0b2bd6d3-187a-4a32-bc07-00d9affab04b.jpg';
  }
  return url;
};

export const PRODUCTS: Product[] = [
  {
    id: 'memo-cx07-cooler',
    name: 'Memo CX07 Magnetic Phone Cooler Fan',
    category: 'Gaming Cooler',
    originalPrice: 1450,
    price: 1150,
    discountPercent: 21,
    rating: 4.9,
    reviewCount: 248,
    stockCount: 15,
    inStock: true,
    isFeatured: true,
    isBestSeller: true,
    image: 'https://i.ibb.co/20qC2vcB/0b2bd6d3-187a-4a32-bc07-00d9affab04b.jpg',
    badgeText: '15W FAST COOLING',
    tagline: '15W rapid cooling performance with instant magnetic snap-on attachment',
    description: '15W magnetic phone cooler fan with fast cooling performance, designed to reduce overheating during gaming, live streaming, video recording, and long-time mobile use. Keeps phone performance stable; compact and portable design suitable for smartphones with magnetic support or magnetic ring attachment.',
    features: [
      'Instant cooling & fast heat reduction for heavy mobile use',
      '15W high-efficiency semiconductor active cooling power',
      'Strong magnetic snap attachment system for MagSafe & magnetic rings',
      'Keeps phone performance stable at locked high FPS without throttling',
      'Engineered for competitive gaming, live streaming & 4K video recording',
      'Compact, lightweight and portable ergonomic design'
    ],
    specs: {
      'Model': 'CX07',
      'Product Type': 'Magnetic Phone Cooler Fan',
      'Cooling Power': '15W High Efficiency Cooling',
      'Key Features': 'Instant cooling / fast heat reduction, magnetic attach system',
      'Recommended Usage': 'Gaming, live streaming, video recording, heavy phone use',
      'Compatibility': 'Smartphones with magnetic support or magnetic ring attachment (Android & iPhone)',
      'Design': 'Compact and portable lightweight form factor',
      'Power Interface': 'Type-C USB input'
    },
    inTheBox: [
      '1x Memo CX07 Magnetic Cooler Fan',
      '1x Magnetic Metal Ring Plate (for Android & non-magnetic phones)',
      '1x Type-C Fast Charging Cable',
      '1x Transparent Protective Film',
      '1x User Manual'
    ]
  },
  {
    id: 'tld-sleeves-v4',
    name: 'TLD Carbon-Silver Pro 24-Needle Gaming Finger Sleeves (Set of 4)',
    category: 'Gaming Finger Sleeves',
    originalPrice: 280,
    price: 220,
    discountPercent: 21,
    rating: 4.9,
    reviewCount: 342,
    stockCount: 45,
    inStock: true,
    isBestSeller: true,
    isFeatured: true,
    image: sleevesImg,
    badgeText: 'HOT SELLER',
    tagline: 'Zero friction, 100% sensitivity for PUBG & FreeFire esports',
    description: 'Constructed with ultra-dense 24-needle superconductor silver fiber weave. Guarantees zero touch lag, absorbs fingertip sweat instantly, and delivers surgical aiming precision during long tournament sessions.',
    features: [
      '24-Needle high-density silver fiber weave with carbon threads',
      '0.25mm ultra-thin breathable fabric keeps fingers dry',
      'Universal 4-way elastic fit for all finger dimensions',
      'Seamless non-scratch edging protects phone glass and screens'
    ],
    specs: {
      'Material': 'Conductive Silver Fiber + High Elastic Spandex',
      'Weave Density': '24-Needle Dense Knit',
      'Thickness': '0.25 mm ultra-thin',
      'Compatibility': 'All Capacitive Touchscreens (iOS & Android)',
      'Quantity': '4 Pieces (2 Pairs) with Metal Storage Case'
    },
    inTheBox: ['4x Silver Pro Gaming Sleeves', '1x Compact Metallic Storage Tin', '1x Authenticity Seal Card']
  },
  {
    id: 'tld-cyberpods-x15',
    name: 'TLD CyberPods X-15 Low Latency (35ms) Gaming TWS Earbuds',
    category: 'Gaming TWS',
    originalPrice: 2450,
    price: 1850,
    discountPercent: 24,
    rating: 4.9,
    reviewCount: 215,
    stockCount: 14,
    inStock: true,
    isBestSeller: true,
    isFeatured: true,
    image: twsImg,
    badgeText: '35ms ULTRA LOW LAG',
    tagline: 'Pinpoint footstep positioning with 13mm titanium drivers',
    description: 'Engineered specifically for competitive mobile esports. Features a specialized Game Mode activating 35ms ultra-low latency, dual noise-cancelling mics for squad communication, and a mecha charging case with neon status indicators.',
    features: [
      'Dedicated Dual-Mode: Low Latency Game Mode & Hi-Fi Music Mode',
      '13mm Titanium-coated dynamic acoustic drivers',
      'ENC Dual-Microphone algorithm filters room background noise',
      'Up to 28 hours total playback with rapid USB-C fast charging'
    ],
    specs: {
      'Bluetooth': 'V5.3 Ultra-stable connection (15m range)',
      'Game Latency': '35ms ultra-low audio-video sync',
      'Battery Life': '6 hours single charge / 28 hours with charging case',
      'Water Resistance': 'IPX5 Sweat & Splash proof',
      'Charging Port': 'USB Type-C Fast Charge (10 mins = 2 hrs play)'
    },
    inTheBox: ['2x CyberPods Earbuds (L & R)', '1x Mecha Armor Charging Case', '3x Pairs Silicone Ear Tips (S/M/L)', '1x Type-C Charging Cable', 'User Manual']
  },
  {
    id: 'tld-tournament-combo-pro',
    name: 'Esports Mobile Dominator Ultimate 5-in-1 Combo Pack',
    category: 'COMBO',
    originalPrice: 2850,
    price: 2150,
    discountPercent: 25,
    rating: 5.0,
    reviewCount: 96,
    stockCount: 3,
    inStock: true,
    isFeatured: true,
    image: comboImg,
    badgeText: 'STOCK LOW: 3 LEFT',
    tagline: 'All-in-one tournament arsenal: Cooler + Triggers + Sleeves + Case',
    description: 'The complete competitive loadout chosen by Bangladeshi mobile tournament winners. Contains the Memo CX07 magnetic cooler, 6-finger alloy mechanical triggers, 4x silver fiber sleeves, and a reinforced EVA shockproof carry vault.',
    features: [
      'Huge savings: 25% off compared to buying items individually',
      'Zero-delay capacitive zinc-alloy mechanical triggers',
      'Semiconductor phone cooler keeps CPU cold and prevents frame drops',
      'Hard EVA storage case holds all components for offline LAN tournaments'
    ],
    specs: {
      'Includes': 'Cooler + Triggers Pair + 4x Sleeves + Hard Case + Cables',
      'Suitability': 'PUBG Mobile, BGMI, FreeFire MAX, CODM, Warzone',
      'Compatibility': 'Smartphones 4.7" to 6.8" screen size',
      'Warranty': '7 Days Instant Replacement Guarantee'
    },
    inTheBox: ['1x Magnetic Phone Cooler', '2x Alloy Pulse Triggers', '4x Pro Silver Sleeves', '1x Hard EVA Travel Case', '1x 90-Degree Gaming Type-C Cable']
  },
  {
    id: 'flydigi-wasp-5',
    name: 'Flydigi Wasp Feelers 5 Glass-Silver Superconductive Sleeves (Pair)',
    category: 'Gaming Finger Sleeves',
    originalPrice: 320,
    price: 260,
    discountPercent: 19,
    rating: 4.8,
    reviewCount: 164,
    stockCount: 22,
    inStock: true,
    image: sleevesImg,
    badgeText: 'PRO GRADE',
    tagline: 'Imported superconducting glass-silver blend for silky gliding',
    description: 'The renowned Flydigi Wasp Feelers 5 features custom aerospace glass-silver yarn. Provides effortless glide on matte and tempered glass screen protectors without losing touch register.',
    features: [
      'Patented glass-silver blend offering 3x higher conductivity',
      'Sweat-proof hydrophobic fiber coating',
      'Form-fit snug weave that does not unravel or stretch loose',
      'Optimal for high-sensitivity claw grip players'
    ],
    specs: {
      'Material': 'Superconductive Glass Silver Fiber',
      'Thickness': '0.3mm reinforced',
      'Quantity': '2 Pieces (1 Pair)',
      'Origin': 'Imported Grade'
    },
    inTheBox: ['2x Flydigi Wasp 5 Sleeves', '1x Steel Metal Carry Case']
  },
  {
    id: 'memo-dl05-cooler',
    name: 'Memo DL05 Digital LED Temperature Display Mobile Phone Cooler',
    category: 'Gaming Cooler',
    originalPrice: 1650,
    price: 1350,
    discountPercent: 18,
    rating: 4.7,
    reviewCount: 142,
    stockCount: 6,
    inStock: true,
    image: coolerImg,
    badgeText: 'TEMP DISPLAY',
    tagline: 'Real-time surface temperature digital readout on back screen',
    description: 'See your device cool in real-time with the bright digital LED readout. Dual-channel semiconductor architecture locks phone core temperatures below 18°C even in humid summer heat.',
    features: [
      'Live digital display shows real-time back plate temperature',
      'Double semiconductor cooling plates for large contact zone',
      'Anti-slip silicone clamps prevent accidental button pressing',
      'Stealth RGB color shifting lights'
    ],
    specs: {
      'Display': 'Digital LED Celsius Readout',
      'Power': '5V/2A input via USB-C',
      'Clamping Width': '65mm - 85mm mobile width',
      'Cooling Range': 'Down to 3°C surface temperature'
    },
    inTheBox: ['1x Memo DL05 Radiator Cooler', '1x 1.5m USB-C Cable', '1x Manual']
  },
  {
    id: 'monster-airmars-xkt08',
    name: 'Monster Airmars XKT08 Mecha Zinc-Alloy Bluetooth 5.3 Earbuds',
    category: 'Gaming TWS',
    originalPrice: 2200,
    price: 1750,
    discountPercent: 20,
    rating: 4.8,
    reviewCount: 128,
    stockCount: 11,
    inStock: true,
    image: twsImg,
    badgeText: 'MECHA METAL',
    tagline: 'Cyberpunk rotating mechanical ring with 360-degree surround sound',
    description: 'Heavy duty zinc-alloy shell with a satisfying fidget spinner mechanical swivel. Delivers deep cinematic bass and instant 45ms gaming sync with high-fidelity acoustic tuning.',
    features: [
      'Full metallic rotating gyro charging frame',
      'Clear voice call pickup with smart environmental noise cancellation',
      'Binaural simultaneous transmission to left and right ears',
      'Hi-Res certified audio performance'
    ],
    specs: {
      'Shell': 'Heavy-duty Zinc Alloy + ABS',
      'Bluetooth': '5.3 stable low-energy',
      'Driver Size': '13mm composite diaphragm',
      'Battery Playtime': '5 hours per charge / 24 hours total'
    },
    inTheBox: ['1x Monster XKT08 TWS Set', '1x Metal Charging Case', '1x USB-C Cable', '1x Lanyard Ring']
  },
  {
    id: 'tld-streamer-rgb-headset',
    name: 'TLD Phantom 7.1 Virtual Surround Esports Gaming Headset',
    category: 'Esports Gaming Headphones',
    originalPrice: 2890,
    price: 2350,
    discountPercent: 19,
    rating: 4.9,
    reviewCount: 79,
    stockCount: 5,
    inStock: true,
    image: twsImg,
    badgeText: '7.1 SURROUND',
    tagline: '50mm neodymium audio drivers with breathable memory foam earmuffs',
    description: 'Multi-platform gaming headset compatible with mobile (via 3.5mm/Type-C dongle) and PC. Features 7.1 virtual surround audio engine for 360-degree enemy awareness and a broadcast-grade noise cancelling boom microphone.',
    features: [
      '50mm Neodymium magnetic drivers tuned for explosive bass and clear mids',
      'Detachable unidirectional cardioid microphone with pop filter',
      'Plush memory protein earmuffs provide all-day comfort without ear sweat',
      'Illuminated neon green ring accents'
    ],
    specs: {
      'Driver Diameter': '50mm',
      'Interface': '3.5mm Gold Jack + USB (for RGB power)',
      'Cable Length': '2.0m braided heavy cable',
      'Weight': '275 grams ultra-comfortable'
    },
    inTheBox: ['1x TLD Phantom Headset', '1x Detachable Boom Mic', '1x 3.5mm 1-to-2 Y-Splitter Cable', '1x Foam Windscreen']
  },
  {
    id: 'tld-gaming-cable-90',
    name: 'TLD 90-Degree L-Shape 66W Super Fast Gaming Type-C Cable (1.5m)',
    category: 'Charger Adapter And Cable',
    originalPrice: 380,
    price: 290,
    discountPercent: 24,
    rating: 4.8,
    reviewCount: 98,
    stockCount: 30,
    inStock: true,
    image: comboImg,
    badgeText: 'ERGONOMIC',
    tagline: 'Right-angle connector never hurts your palm while holding horizontal',
    description: 'Designed specifically for landscape mobile gaming. The 90-degree right angle plug hugs the phone body smoothly, allowing a natural two-handed grip with no cable bent stress or wrist fatigue.',
    features: [
      '66W SuperCharge & 3A fast charging with smart IC temperature control',
      'High-density ballistic nylon braided exterior resists 20,000+ bends',
      'Built-in green LED power status light for easy finding in the dark',
      'Gold-plated anti-oxidation contact pins'
    ],
    specs: {
      'Length': '1.5 Meters (5 Feet)',
      'Max Power': '66W Max (Compatible with 18W, 33W, 65W, 67W, 120W protocols)',
      'Data Rate': '480 Mbps transfer speed',
      'Connector': 'USB-A to 90-Degree USB Type-C'
    },
    inTheBox: ['1x 90-Degree 1.5m Braided Cable', '1x Reusable Velcro Cable Tie']
  },
  {
    id: 'tld-solo-tournament-combo',
    name: 'Pro PUBG / FreeFire Solo Tournament Kit (Sleeves + Triggers + Storage Case)',
    category: 'COMBO',
    originalPrice: 750,
    price: 580,
    discountPercent: 23,
    rating: 4.9,
    reviewCount: 88,
    stockCount: 15,
    inStock: true,
    image: comboImg,
    badgeText: 'BUDGET CHAMP',
    tagline: 'Essential duo for rising mobile warriors aiming for Conqueror rank',
    description: 'The highest value starter bundle for competitive battle royale enthusiasts. Includes 2 pairs of silver-carbon sleeves and a pair of dual mechanical alloy triggers packed into a metallic carrying capsule.',
    features: [
      'Perfect entry set for aspiring esports players on budget',
      'Immediate recoil control improvement with tactile triggers',
      '4x sweat-wicking silver finger sleeves',
      'Durable metallic storage tin prevents loss in backpacks'
    ],
    specs: {
      'Contents': '4x Silver Sleeves + 2x Triggers + Metal Storage Case',
      'Suitability': 'Any Android & iPhone device',
      'Warranty': '7 Days Replacement'
    },
    inTheBox: ['4x Silver Pro Sleeves', '2x Mechanical Triggers', '1x Tin Case']
  },
  {
    id: 'magnetic-heatsink-plate-kit',
    name: 'Universal Magnetic Heat Sink Plate & Spring Clamp Holder Kit',
    category: 'Cooler Clips and Heat Sink Magnetic Plate',
    originalPrice: 350,
    price: 250,
    discountPercent: 28,
    rating: 4.8,
    reviewCount: 65,
    stockCount: 35,
    inStock: true,
    image: coolerImg,
    badgeText: 'HEAT SINK',
    tagline: 'Expands semiconductor cooling area by 300% across whole phone back',
    description: 'Composite thermal conductive copper and aluminum magnetic sticker sheet. Converts any smartphone or iPad into a MagSafe compatible surface for magnetic coolers like Memo CX07.',
    features: [
      'Aerospace grade thermal conductive copper sheet accelerates heat dispersion',
      'Strong permanent neodymium magnetic force holds coolers tightly',
      '0.4mm ultra-thin profile fits seamlessly under thin protective phone covers',
      'Includes 2x spring clip silicone hooks for non-magnetic attachment'
    ],
    specs: {
      'Material': 'Conductive Copper Foil + Magnetic Ferrous Core',
      'Thickness': '0.4mm',
      'Diameter': '60mm circular universal',
      'Includes': '2x Heat Sink Plates + 1x Spring Grip Clamp + 2x Electrostatic Films'
    },
    inTheBox: ['2x Magnetic Thermal Heat Sink Plates', '1x Spring Clamp Bracket', '2x Cleaning Wipes']
  },
  {
    id: 'cyberpunk-gaming-powerbank-22w',
    name: 'CyberPower 22.5W 10000mAh Transparent Mecha Fast Charge Power Bank',
    category: 'Power Bank',
    originalPrice: 1950,
    price: 1490,
    discountPercent: 24,
    rating: 4.9,
    reviewCount: 114,
    stockCount: 10,
    inStock: true,
    image: comboImg,
    badgeText: 'TRANSPARENT',
    tagline: 'Cyberpunk see-through chassis with digital battery display and 22.5W output',
    description: 'High performance portable gaming power bank with visible internal circuits and gold cyber accents. Powers magnetic coolers and smartphones simultaneously with dual fast charging protocols.',
    features: [
      '22.5W Super Fast Charge supports PD 3.0, QC 4.0, and SCP/FCP',
      'Dual output: USB-A + Type-C two-way rapid charging',
      'Smart LED digital screen accurately displays battery percentage',
      'Airline flight approved 10,000mAh high-density polymer cell'
    ],
    specs: {
      'Capacity': '10,000mAh / 37Wh',
      'Output': '22.5W Max (Type-C: 20W PD, USB-A: 22.5W SuperCharge)',
      'Input': 'Type-C 18W Fast Recharge',
      'Weight': '210 grams compact pocket size'
    },
    inTheBox: ['1x CyberPower 10000mAh Power Bank', '1x 30cm Type-C Fast Charging Cable', 'User Manual']
  }
];
