import React, { useMemo } from 'react';
import { ShopProvider, useShop } from './context/ShopContext';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { CategoryFilterBar } from './components/CategoryFilterBar';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderConfirmationModal } from './components/OrderConfirmationModal';
import { TrustBadges } from './components/TrustBadges';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton';
import { PolicyModal } from './components/PolicyModal';
import { Footer } from './components/Footer';
import { MobileMenuDrawer } from './components/MobileMenuDrawer';
import { AuthModal } from './components/AuthModal';
import { DigitalGoodsView } from './components/DigitalGoodsView';
import { LeaderboardView } from './components/LeaderboardView';
import { PRODUCTS } from './data/products';
import { Zap, PackageX, Sparkles } from 'lucide-react';

const ShopContent: React.FC = () => {
  const { 
    isDark,
    selectedCategory, 
    searchQuery, 
    sortBy, 
    setSearchQuery, 
    setSelectedCategory,
    toastMessage,
    activeTab
  } = useShop();

  // Filter & Sort products
  const filteredProducts = useMemo(() => {
    let list = [...PRODUCTS];

    // Category filter
    if (selectedCategory !== 'All') {
      list = list.filter((p) => p.category === selectedCategory);
    }

    // Search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.tagline.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.features.some((f) => f.toLowerCase().includes(q))
      );
    }

    // Sorting
    switch (sortBy) {
      case 'price-asc':
        list.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        list.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        list.sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount);
        break;
      case 'discount':
        list.sort((a, b) => b.discountPercent - a.discountPercent);
        break;
      case 'featured':
      default:
        // Best sellers and featured first
        list.sort((a, b) => (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0));
        break;
    }

    return list;
  }, [selectedCategory, searchQuery, sortBy]);

  return (
    <div className={`min-h-screen transition-colors duration-200 ${
      isDark ? 'bg-neutral-950 text-neutral-100' : 'bg-neutral-100 text-neutral-900'
    } flex flex-col selection:bg-emerald-500 selection:text-black w-full max-w-[100vw] overflow-x-hidden box-border`}>
      {/* Top Navbar */}
      <Header />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-full overflow-x-hidden">
        {activeTab === 'digital' ? (
          <DigitalGoodsView />
        ) : activeTab === 'leaderboard' ? (
          <LeaderboardView />
        ) : (
          <>
            {/* Promotional Hero Carousel (visible when not deep in search to avoid clutter) */}
            {!searchQuery && <HeroBanner />}

            {/* Category Filter Bar */}
            <CategoryFilterBar />

            {/* Product Grid Section (Mobile-First 2-Column Grid) */}
            <section className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 w-full box-border">
              {filteredProducts.length === 0 ? (
                <div className="py-16 text-center bg-neutral-900/60 rounded-2xl border border-neutral-800 p-8 space-y-4 max-w-lg mx-auto">
                  <div className="w-16 h-16 rounded-full bg-neutral-800 flex items-center justify-center mx-auto text-neutral-500">
                    <PackageX className="w-8 h-8 text-neutral-500" />
                  </div>
                  <h3 className="text-lg font-bold text-white font-display uppercase tracking-wide">
                    No Gadgets Found
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-400">
                    We couldn't find any products matching your current filters. Try resetting search or checking another category.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('All');
                    }}
                    className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-lg transition-all cursor-pointer"
                  >
                    Reset Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-5">
                  {filteredProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              )}
            </section>
          </>
        )}

        {/* Trust Badges */}
        <TrustBadges />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating WhatsApp Action Button */}
      <WhatsAppFloatingButton />

      {/* Modals & Drawers */}
      <MobileMenuDrawer />
      <AuthModal />
      <ProductDetailModal />
      <CartDrawer />
      <WishlistDrawer />
      <CheckoutModal />
      <OrderConfirmationModal />
      <PolicyModal />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 animate-in fade-in slide-in-from-top-3 duration-200 pointer-events-none">
          <div className="px-4 py-2.5 rounded-lg bg-neutral-900 border border-emerald-500/50 shadow-[0_4px_20px_rgba(16,185,129,0.3)] text-white text-xs font-semibold flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <ShopProvider>
      <ShopContent />
    </ShopProvider>
  );
}
