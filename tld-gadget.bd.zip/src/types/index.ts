export type ProductCategory = 
  | 'All'
  | 'Gaming Finger Sleeves'
  | 'Esports Gaming Headphones'
  | 'Gaming Cooler'
  | 'COMBO'
  | 'Charger Adapter And Cable'
  | 'Gaming TWS'
  | 'Cooler Clips and Heat Sink Magnetic Plate'
  | 'Power Bank'
  | string;

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  originalPrice: number; // in BDT
  price: number; // in BDT
  discountPercent: number;
  rating: number;
  reviewCount: number;
  stockCount: number;
  inStock: boolean;
  isFeatured?: boolean;
  isBestSeller?: boolean;
  image: string;
  badgeText?: string;
  tagline: string;
  description: string;
  features: string[];
  specs: { [key: string]: string };
  inTheBox: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface CheckoutForm {
  customerName: string;
  phone: string;
  address: string;
  city: 'dhaka' | 'outside_dhaka';
  areaNote?: string;
  paymentMethod: 'cod' | 'bkash' | 'nagad';
  trxId?: string;
}

export interface Order {
  orderId: string;
  createdAt: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  discountAmount: number;
  couponCode?: string;
  totalAmount: number;
  shippingDetails: CheckoutForm;
  status: 'Confirmed' | 'Shipped' | 'Delivered';
}
